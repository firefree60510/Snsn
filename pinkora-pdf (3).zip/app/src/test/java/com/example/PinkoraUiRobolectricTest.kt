package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.data.model.PdfDocumentRecord
import com.example.data.model.UserSettings
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.PinkoraPdfTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PinkoraUiRobolectricTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun `home screen shows hero card 4 actions and empty state when no pdfs exist`() {
    composeTestRule.setContent {
      PinkoraPdfTheme {
        HomeScreen(
          recentDocuments = emptyList(),
          onOpenGalleryPicker = {},
          onOpenScanner = {},
          onOpenCreateSourceDialog = {},
          onOpenMyFiles = {},
          onOpenSettings = {},
          onOpenDocument = {},
          onShareDocument = {},
          onRenameDocument = { _, _ -> },
          onDeleteDocument = {},
          onRemoveStaleRecord = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Your Documents, Perfectly Organized").assertIsDisplayed()
    composeTestRule.onNodeWithTag("action_gallery_to_pdf").assertIsDisplayed()
    composeTestRule.onNodeWithTag("action_scan_document").assertIsDisplayed()
    composeTestRule.onNodeWithTag("action_create_pdf").assertIsDisplayed()
    composeTestRule.onNodeWithTag("action_my_pdfs").assertIsDisplayed()
    composeTestRule.onNodeWithTag("create_first_pdf_button").assertIsDisplayed()
  }

  @Test
  fun `home screen renders saved documents when present`() {
    val sampleDoc =
      PdfDocumentRecord(
        id = 1L,
        displayName = "Pinkora_Document_2026-11-22_001.pdf",
        filePath = "/tmp/fake.pdf",
        createdAt = System.currentTimeMillis(),
        pageCount = 3,
        fileSizeBytes = 204800L,
        thumbnailPath = null,
        fileExists = true,
      )

    composeTestRule.setContent {
      PinkoraPdfTheme {
        HomeScreen(
          recentDocuments = listOf(sampleDoc),
          onOpenGalleryPicker = {},
          onOpenScanner = {},
          onOpenCreateSourceDialog = {},
          onOpenMyFiles = {},
          onOpenSettings = {},
          onOpenDocument = {},
          onShareDocument = {},
          onRenameDocument = { _, _ -> },
          onDeleteDocument = {},
          onRemoveStaleRecord = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("pdf_item_card_1").assertIsDisplayed()
    composeTestRule.onNodeWithText("Pinkora_Document_2026-11-22_001.pdf").assertIsDisplayed()
  }

  @Test
  fun `settings screen shows theme options and privacy notice`() {
    composeTestRule.setContent {
      PinkoraPdfTheme {
        SettingsScreen(
          settings = UserSettings(),
          documents = emptyList(),
          onUpdateTheme = {},
          onUpdateDefaultPageSize = {},
          onUpdateDefaultQuality = {},
          onUpdateNamingPrefix = {},
          onUpdateIncludeMargins = {},
          onShowMessage = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("theme_chip_LIGHT").assertIsDisplayed()
    composeTestRule.onNodeWithTag("theme_chip_DARK").assertIsDisplayed()
    composeTestRule.onNodeWithTag("theme_chip_SYSTEM").assertIsDisplayed()
  }
}
