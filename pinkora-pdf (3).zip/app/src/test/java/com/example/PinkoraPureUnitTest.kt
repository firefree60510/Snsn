package com.example

import com.example.ads.AdMobConfig
import com.example.data.model.CropRect
import com.example.data.model.PdfPageSize
import com.example.data.model.PdfQuality
import com.example.data.model.ResizePreset
import com.example.data.model.ScanFilter
import com.example.ui.components.formatFileSize
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PinkoraPureUnitTest {

  @Test
  fun `admob config uses official google test ad unit ids`() {
    assertTrue(AdMobConfig.TEST_APP_ID.startsWith("ca-app-pub-3940256099942544~"))
    assertTrue(AdMobConfig.BANNER_AD_UNIT_ID.startsWith("ca-app-pub-3940256099942544/"))
    assertTrue(AdMobConfig.INTERSTITIAL_AD_UNIT_ID.startsWith("ca-app-pub-3940256099942544/"))
    assertTrue(AdMobConfig.REWARDED_AD_UNIT_ID.startsWith("ca-app-pub-3940256099942544/"))
    assertTrue(AdMobConfig.NATIVE_AD_UNIT_ID.startsWith("ca-app-pub-3940256099942544/"))
  }

  @Test
  fun `crop rect detects full vs cropped regions accurately`() {
    val full = CropRect()
    assertTrue(full.isFull)
    assertEquals(1f, full.width, 0.001f)
    assertEquals(1f, full.height, 0.001f)

    val cropped = CropRect(left = 0.1f, top = 0.2f, right = 0.85f, bottom = 0.9f)
    assertFalse(cropped.isFull)
    assertEquals(0.75f, cropped.width, 0.001f)
    assertEquals(0.70f, cropped.height, 0.001f)
  }

  @Test
  fun `pdf page sizes and quality presets are properly configured`() {
    assertEquals(595, PdfPageSize.A4.widthPt)
    assertEquals(842, PdfPageSize.A4.heightPt)
    assertEquals(612, PdfPageSize.LETTER.widthPt)
    assertEquals(792, PdfPageSize.LETTER.heightPt)
    assertTrue(PdfQuality.HIGH.jpegQuality > PdfQuality.MEDIUM.jpegQuality)
    assertTrue(PdfQuality.MEDIUM.jpegQuality > PdfQuality.LOW.jpegQuality)
    assertEquals(5, ScanFilter.entries.size)
    assertEquals(4, ResizePreset.entries.size)
  }

  @Test
  fun `file size formatter formats bytes kb and mb cleanly`() {
    assertEquals("512 B", formatFileSize(512L))
    assertEquals("2.0 KB", formatFileSize(2048L))
    assertEquals("1.50 MB", formatFileSize(1572864L))
  }
}
