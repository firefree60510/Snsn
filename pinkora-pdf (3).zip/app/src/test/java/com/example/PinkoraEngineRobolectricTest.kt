package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.PinkoraDatabase
import com.example.data.model.CropRect
import com.example.data.model.PdfGenerationConfig
import com.example.data.model.PdfImageFit
import com.example.data.model.PdfOrientation
import com.example.data.model.PdfPageSize
import com.example.data.model.PdfQuality
import com.example.data.model.ResizePreset
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedPage
import com.example.data.repository.DocumentRepository
import com.example.engine.ImageProcessor
import com.example.engine.PdfEngine
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PinkoraEngineRobolectricTest {

  private lateinit var context: Context
  private lateinit var db: PinkoraDatabase
  private lateinit var repo: DocumentRepository
  private lateinit var workDir: File

  @Before
  fun setup() {
    context = ApplicationProvider.getApplicationContext()
    db = Room.inMemoryDatabaseBuilder(context, PinkoraDatabase::class.java).allowMainThreadQueries().build()
    repo = DocumentRepository(context, db.documentDao())
    workDir = File(context.cacheDir, "test_work").apply {
      deleteRecursively()
      mkdirs()
    }
  }

  @After
  fun tearDown() {
    db.close()
    workDir.deleteRecursively()
  }

  private fun createSyntheticDocumentImage(name: String, bgColor: Int, paperColor: Int = Color.WHITE): File {
    val bmp = Bitmap.createBitmap(400, 560, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    canvas.drawColor(bgColor)
    val paint = Paint().apply { color = paperColor }
    canvas.drawRect(60f, 80f, 340f, 480f, paint)
    // Add dark ink lines on paper
    val textPaint = Paint().apply {
      color = Color.BLACK
      strokeWidth = 6f
    }
    canvas.drawLine(90f, 140f, 300f, 140f, textPaint)
    canvas.drawLine(90f, 200f, 270f, 200f, textPaint)

    val outFile = File(workDir, name)
    FileOutputStream(outFile).use { fos -> bmp.compress(Bitmap.CompressFormat.JPEG, 92, fos) }
    bmp.recycle()
    return outFile
  }

  @Test
  fun `auto edge detection detects bright paper inside dark border`() {
    val file = createSyntheticDocumentImage("doc_on_desk.jpg", bgColor = Color.rgb(30, 30, 35))
    val bmp = ImageProcessor.decodeSampledBitmapFromFile(file, 800)!!
    val rect = ImageProcessor.detectDocumentEdges(bmp)
    bmp.recycle()

    assertFalse("Expected tighter crop than full frame", rect.isFull)
    assertTrue("Left should be inset near 0.15", rect.left in 0.05f..0.25f)
    assertTrue("Right should be inset near 0.85", rect.right in 0.75f..0.95f)
  }

  @Test
  fun `crop rotate resize and filters produce valid transformed bitmap`() = runTest {
    val file = createSyntheticDocumentImage("transform.jpg", bgColor = Color.DKGRAY)
    val page =
      ScannedPage(
        sourceFilePath = file.absolutePath,
        rotationDegrees = 90,
        cropRect = CropRect(0.1f, 0.1f, 0.9f, 0.9f),
        filter = ScanFilter.BLACK_WHITE,
        resizePreset = ResizePreset.SQUARE,
        resizeScale = 0.75f,
      )

    val outBmp = ImageProcessor.renderProcessedBitmap(page, maxDimension = 800, applyCrop = true)
    assertNotNull(outBmp)
    // Square preset enforces equal width and height
    assertEquals(outBmp!!.width, outBmp.height)
    outBmp.recycle()
  }

  @Test
  fun `generate single and five page pdf preserves page count and order`() = runTest {
    val pages =
      (1..5).map { idx ->
        val f = createSyntheticDocumentImage("page_$idx.jpg", bgColor = Color.GRAY)
        ScannedPage(
          sourceFilePath = f.absolutePath,
          filter = if (idx % 2 == 0) ScanFilter.ENHANCED else ScanFilter.GRAYSCALE,
        )
      }

    val (outPdf, outThumb) = repo.resolveUniqueTargetFiles("Test_Five_Page")
    val progressSteps = mutableListOf<Int>()
    val result =
      PdfEngine.generatePdfFromPages(
        context = context,
        pages = pages,
        config =
          PdfGenerationConfig(
            fileName = "Test_Five_Page",
            pageSize = PdfPageSize.A4,
            orientation = PdfOrientation.PORTRAIT,
            imageFit = PdfImageFit.PRESERVE_ASPECT,
            quality = PdfQuality.MEDIUM,
            includeMargins = true,
          ),
        outputPdfFile = outPdf,
        outputThumbFile = outThumb,
        onProgress = { cur, _ -> progressSteps.add(cur) },
      )

    assertTrue(result.isSuccess)
    val generated = result.getOrThrow()
    assertEquals(5, generated.pageCount)
    assertTrue(generated.fileSizeBytes > 0L)
    assertTrue(generated.pdfFile.exists())
    assertEquals(listOf(1, 2, 3, 4, 5), progressSteps)
  }

  @Test
  fun `repository sanitizes filenames avoids collisions renames and deletes cleanly`() = runTest {
    assertEquals("My_Invoice_2026", repo.sanitizeFilename("My/Invoice:2026*?"))

    val file1 = createSyntheticDocumentImage("p1.jpg", Color.BLACK)
    val (pdf1, thumb1) = repo.resolveUniqueTargetFiles("Report")
    val res1 =
      PdfEngine.generatePdfFromPages(
        context,
        listOf(ScannedPage(sourceFilePath = file1.absolutePath)),
        PdfGenerationConfig("Report"),
        pdf1,
        thumb1,
      ) { _, _ -> }
    val rec1 = repo.registerGeneratedPdf(res1.getOrThrow())

    // Second file with same requested name should not overwrite first
    val (pdf2, _) = repo.resolveUniqueTargetFiles("Report")
    assertTrue(pdf2.name != pdf1.name)

    val renamed = repo.renameDocument(rec1, "Renamed_Report").getOrThrow()
    assertEquals("Renamed_Report.pdf", renamed.displayName)
    assertTrue(File(renamed.filePath).exists())

    val listBeforeDelete = repo.documentsFlow.first()
    assertEquals(1, listBeforeDelete.size)

    repo.deleteDocument(renamed).getOrThrow()
    assertFalse(File(renamed.filePath).exists())
    assertEquals(0, repo.documentsFlow.first().size)
  }

  @Test
  fun `empty page list returns failure safely`() = runTest {
    val (outPdf, outThumb) = repo.resolveUniqueTargetFiles("Empty")
    val res =
      PdfEngine.generatePdfFromPages(
        context,
        emptyList(),
        PdfGenerationConfig("Empty"),
        outPdf,
        outThumb,
      ) { _, _ -> }
    assertTrue(res.isFailure)
    assertFalse(outPdf.exists())
  }
}
