package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.example.data.local.DocumentDao
import com.example.data.local.DocumentEntity
import com.example.data.model.PdfDocumentRecord
import com.example.engine.GeneratedPdfResult
import com.example.engine.PdfEngine
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class DocumentRepository(
  private val context: Context,
  private val dao: DocumentDao,
) {

  private val pdfsDir: File
    get() = File(context.filesDir, "pdfs").apply { mkdirs() }

  private val thumbsDir: File
    get() = File(context.filesDir, "thumbs").apply { mkdirs() }

  val documentsFlow: Flow<List<PdfDocumentRecord>> =
    dao.observeAllDocuments().map { list ->
      list.map { entity ->
        val file = File(entity.filePath)
        val thumb = entity.thumbnailPath?.let { File(it) }?.takeIf { it.exists() }?.absolutePath
        PdfDocumentRecord(
          id = entity.id,
          displayName = entity.displayName,
          filePath = entity.filePath,
          createdAt = entity.createdAt,
          pageCount = entity.pageCount,
          fileSizeBytes = if (file.exists()) file.length() else entity.fileSizeBytes,
          thumbnailPath = thumb,
          fileExists = file.exists() && file.length() > 0L,
        )
      }
    }

  fun suggestNextPdfName(prefix: String = "Pinkora_Document"): String {
    val cleanPrefix = sanitizeFilename(prefix).ifBlank { "Pinkora_Document" }
    val datePart = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val existing = pdfsDir.listFiles()?.map { it.nameWithoutExtension }?.toSet() ?: emptySet()
    for (seq in 1..999) {
      val candidate = "${cleanPrefix}_${datePart}_%03d".format(Locale.US, seq)
      if (candidate !in existing) {
        return "$candidate.pdf"
      }
    }
    return "${cleanPrefix}_${datePart}_${System.currentTimeMillis()}.pdf"
  }

  fun resolveUniqueTargetFiles(requestedName: String): Pair<File, File> {
    val sanitizedBase =
      sanitizeFilename(requestedName.removeSuffix(".pdf").removeSuffix(".PDF"))
        .ifBlank { "Pinkora_Document" }
    var candidateName = "$sanitizedBase.pdf"
    var counter = 1
    while (File(pdfsDir, candidateName).exists()) {
      candidateName = "${sanitizedBase}_($counter).pdf"
      counter++
    }
    val pdfFile = File(pdfsDir, candidateName)
    val thumbFile = File(thumbsDir, "${pdfFile.nameWithoutExtension}_${System.currentTimeMillis()}.jpg")
    return pdfFile to thumbFile
  }

  suspend fun registerGeneratedPdf(result: GeneratedPdfResult): PdfDocumentRecord =
    withContext(Dispatchers.IO) {
      val entity =
        DocumentEntity(
          displayName = result.pdfFile.name,
          filePath = result.pdfFile.absolutePath,
          createdAt = System.currentTimeMillis(),
          pageCount = result.pageCount,
          fileSizeBytes = result.fileSizeBytes,
          thumbnailPath = result.thumbnailFile?.absolutePath,
        )
      val id = dao.insertDocument(entity)
      PdfDocumentRecord(
        id = id,
        displayName = entity.displayName,
        filePath = entity.filePath,
        createdAt = entity.createdAt,
        pageCount = entity.pageCount,
        fileSizeBytes = entity.fileSizeBytes,
        thumbnailPath = entity.thumbnailPath,
        fileExists = true,
      )
    }

  suspend fun importExternalPdf(uri: Uri): Result<PdfDocumentRecord> =
    withContext(Dispatchers.IO) {
      runCatching {
        val rawName = resolveDisplayName(uri) ?: suggestNextPdfName("Imported_PDF")
        val (pdfFile, thumbFile) = resolveUniqueTargetFiles(rawName)
        context.contentResolver.openInputStream(uri)?.use { input ->
          FileOutputStream(pdfFile).use { output -> input.copyTo(output) }
        } ?: error("Cannot read selected PDF.")

        val pageCount = PdfEngine.verifyPdfPageCount(pdfFile)
        if (pageCount <= 0) {
          pdfFile.delete()
          error("The selected file is not a valid or readable PDF.")
        }
        val savedThumb = PdfEngine.generateThumbnailFromPdf(pdfFile, thumbFile)
        registerGeneratedPdf(
          GeneratedPdfResult(
            pdfFile = pdfFile,
            thumbnailFile = savedThumb,
            pageCount = pageCount,
            fileSizeBytes = pdfFile.length(),
          )
        )
      }
    }

  suspend fun renameDocument(record: PdfDocumentRecord, newRawName: String): Result<PdfDocumentRecord> =
    withContext(Dispatchers.IO) {
      runCatching {
        val currentFile = File(record.filePath)
        if (!currentFile.exists()) error("File no longer exists on disk.")

        val cleanBase =
          sanitizeFilename(newRawName.removeSuffix(".pdf").removeSuffix(".PDF"))
            .ifBlank { error("Please enter a valid file name.") }
        var targetFile = File(pdfsDir, "$cleanBase.pdf")
        if (targetFile.absolutePath != currentFile.absolutePath) {
          var suffix = 1
          while (targetFile.exists()) {
            targetFile = File(pdfsDir, "${cleanBase}_($suffix).pdf")
            suffix++
          }
          if (!currentFile.renameTo(targetFile)) {
            error("Unable to rename file.")
          }
        }

        val updated =
          DocumentEntity(
            id = record.id,
            displayName = targetFile.name,
            filePath = targetFile.absolutePath,
            createdAt = record.createdAt,
            pageCount = record.pageCount,
            fileSizeBytes = targetFile.length(),
            thumbnailPath = record.thumbnailPath,
          )
        dao.updateDocument(updated)
        record.copy(
          displayName = updated.displayName,
          filePath = updated.filePath,
          fileSizeBytes = updated.fileSizeBytes,
        )
      }
    }

  suspend fun deleteDocument(record: PdfDocumentRecord): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val file = File(record.filePath)
        if (file.exists()) file.delete()
        record.thumbnailPath?.let { File(it) }?.takeIf { it.exists() }?.delete()
        dao.deleteDocumentById(record.id)
      }
    }

  suspend fun removeStaleRecord(id: Long) {
    withContext(Dispatchers.IO) { dao.deleteDocumentById(id) }
  }

  suspend fun exportPdfToUri(record: PdfDocumentRecord, destinationUri: Uri): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val source = File(record.filePath)
        if (!source.exists() || source.length() == 0L) error("Source PDF file is missing.")
        context.contentResolver.openOutputStream(destinationUri)?.use { out ->
          source.inputStream().use { input -> input.copyTo(out) }
          out.flush()
        } ?: error("Failed to open destination output stream.")
      }
    }

  suspend fun getDocumentById(id: Long): PdfDocumentRecord? =
    withContext(Dispatchers.IO) {
      dao.getDocumentById(id)?.let { entity ->
        val file = File(entity.filePath)
        PdfDocumentRecord(
          id = entity.id,
          displayName = entity.displayName,
          filePath = entity.filePath,
          createdAt = entity.createdAt,
          pageCount = entity.pageCount,
          fileSizeBytes = if (file.exists()) file.length() else entity.fileSizeBytes,
          thumbnailPath = entity.thumbnailPath?.takeIf { File(it).exists() },
          fileExists = file.exists() && file.length() > 0L,
        )
      }
    }

  fun getShareableUri(filePath: String): Uri? {
    val file = File(filePath)
    if (!file.exists()) return null
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
  }

  fun buildShareIntent(record: PdfDocumentRecord): Intent? {
    val uri = getShareableUri(record.filePath) ?: return null
    val sendIntent =
      Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, record.displayName)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
    return Intent.createChooser(sendIntent, "Share ${record.displayName}")
  }

  fun buildOpenExternalIntent(record: PdfDocumentRecord): Intent? {
    val uri = getShareableUri(record.filePath) ?: return null
    val viewIntent =
      Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/pdf")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
    return Intent.createChooser(viewIntent, "Open ${record.displayName}")
  }

  fun resolveDisplayName(uri: Uri): String? {
    return runCatching {
      context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
          val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
          if (idx >= 0) cursor.getString(idx) else null
        } else null
      }
    }.getOrNull()
  }

  fun sanitizeFilename(input: String): String {
    return input.trim()
      .replace(Regex("[\\\\/:*?\"<>|\\x00-\\x1F]"), "_")
      .replace(Regex("\\s+"), "_")
      .trim('.')
      .take(80)
  }
}
