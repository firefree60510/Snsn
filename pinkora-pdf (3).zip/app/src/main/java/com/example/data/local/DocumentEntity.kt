package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pdf_documents")
data class DocumentEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val displayName: String,
  val filePath: String,
  val createdAt: Long,
  val pageCount: Int,
  val fileSizeBytes: Long,
  val thumbnailPath: String?,
)
