package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [DocumentEntity::class], version = 1, exportSchema = false)
abstract class PinkoraDatabase : RoomDatabase() {
  abstract fun documentDao(): DocumentDao

  companion object {
    @Volatile
    private var INSTANCE: PinkoraDatabase? = null

    fun getInstance(context: Context): PinkoraDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                PinkoraDatabase::class.java,
                "pinkora_pdf.db",
              )
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
