package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
  @Query("SELECT * FROM pdf_documents ORDER BY createdAt DESC")
  fun observeAllDocuments(): Flow<List<DocumentEntity>>

  @Query("SELECT * FROM pdf_documents WHERE id = :id LIMIT 1")
  suspend fun getDocumentById(id: Long): DocumentEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDocument(entity: DocumentEntity): Long

  @Update
  suspend fun updateDocument(entity: DocumentEntity)

  @Query("DELETE FROM pdf_documents WHERE id = :id")
  suspend fun deleteDocumentById(id: Long)
}
