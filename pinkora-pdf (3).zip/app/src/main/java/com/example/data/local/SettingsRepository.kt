package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.PdfPageSize
import com.example.data.model.PdfQuality
import com.example.data.model.ThemePreference
import com.example.data.model.UserSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pinkora_settings")

class SettingsRepository(private val context: Context) {

  private object Keys {
    val THEME = stringPreferencesKey("theme_preference")
    val PAGE_SIZE = stringPreferencesKey("default_page_size")
    val QUALITY = stringPreferencesKey("default_quality")
    val NAMING_PREFIX = stringPreferencesKey("default_naming_prefix")
    val INCLUDE_MARGINS = booleanPreferencesKey("include_margins")
  }

  val settingsFlow: Flow<UserSettings> =
    context.dataStore.data.map { prefs ->
      UserSettings(
        themePreference =
          prefs[Keys.THEME]?.let { runCatching { ThemePreference.valueOf(it) }.getOrNull() }
            ?: ThemePreference.LIGHT,
        defaultPageSize =
          prefs[Keys.PAGE_SIZE]?.let { runCatching { PdfPageSize.valueOf(it) }.getOrNull() }
            ?: PdfPageSize.A4,
        defaultQuality =
          prefs[Keys.QUALITY]?.let { runCatching { PdfQuality.valueOf(it) }.getOrNull() }
            ?: PdfQuality.HIGH,
        defaultNamingPrefix =
          prefs[Keys.NAMING_PREFIX]?.takeIf { it.isNotBlank() } ?: "Pinkora_Document",
        includeMargins = prefs[Keys.INCLUDE_MARGINS] ?: true,
      )
    }

  suspend fun updateTheme(theme: ThemePreference) {
    context.dataStore.edit { it[Keys.THEME] = theme.name }
  }

  suspend fun updateDefaultPageSize(size: PdfPageSize) {
    context.dataStore.edit { it[Keys.PAGE_SIZE] = size.name }
  }

  suspend fun updateDefaultQuality(quality: PdfQuality) {
    context.dataStore.edit { it[Keys.QUALITY] = quality.name }
  }

  suspend fun updateDefaultNamingPrefix(prefix: String) {
    val sanitized = prefix.trim().replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "Pinkora_Document" }
    context.dataStore.edit { it[Keys.NAMING_PREFIX] = sanitized }
  }

  suspend fun updateIncludeMargins(include: Boolean) {
    context.dataStore.edit { it[Keys.INCLUDE_MARGINS] = include }
  }
}
