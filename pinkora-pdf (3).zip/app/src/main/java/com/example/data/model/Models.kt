package com.example.data.model

import java.util.UUID

enum class ThemePreference(val label: String) {
  LIGHT("Light"),
  DARK("Dark"),
  SYSTEM("System Default"),
}

enum class PdfPageSize(val label: String, val widthPt: Int, val heightPt: Int) {
  A4("A4", 595, 842),
  LETTER("Letter", 612, 792),
  ORIGINAL("Original Ratio", 0, 0),
}

enum class PdfOrientation(val label: String) {
  PORTRAIT("Portrait"),
  LANDSCAPE("Landscape"),
}

enum class PdfImageFit(val label: String) {
  FIT_TO_PAGE("Fit to Page"),
  PRESERVE_ASPECT("Preserve Aspect Ratio"),
}

enum class PdfQuality(val label: String, val maxDimensionPx: Int, val jpegQuality: Int) {
  HIGH("High (Best Text)", 2200, 92),
  MEDIUM("Medium (Balanced)", 1600, 80),
  LOW("Compact (Small Size)", 1100, 62),
}

enum class ScanFilter(val label: String) {
  ORIGINAL("Original"),
  ENHANCED("Color Boost"),
  GRAYSCALE("Grayscale"),
  BLACK_WHITE("B&W Doc"),
  HIGH_CONTRAST("Sharp Ink"),
}

enum class ResizePreset(val label: String, val aspectRatio: Float?) {
  ORIGINAL("Original", null),
  A4_RATIO("A4 (1:1.41)", 1f / 1.414f),
  LETTER_RATIO("Letter (1:1.29)", 8.5f / 11f),
  SQUARE("Square (1:1)", 1f),
}

enum class PdfSortOption(val label: String) {
  NEWEST("Newest First"),
  OLDEST("Oldest First"),
  NAME("Name (A–Z)"),
  SIZE("File Size"),
}

data class CropRect(
  val left: Float = 0f,
  val top: Float = 0f,
  val right: Float = 1f,
  val bottom: Float = 1f,
) {
  val width: Float get() = (right - left).coerceAtLeast(0.08f)
  val height: Float get() = (bottom - top).coerceAtLeast(0.08f)
  val isFull: Boolean get() = left <= 0.005f && top <= 0.005f && right >= 0.995f && bottom >= 0.995f
}

data class ScannedPage(
  val id: String = UUID.randomUUID().toString(),
  val sourceFilePath: String,
  val rotationDegrees: Int = 0,
  val cropRect: CropRect = CropRect(),
  val autoDetectedCropRect: CropRect? = null,
  val filter: ScanFilter = ScanFilter.ORIGINAL,
  val resizePreset: ResizePreset = ResizePreset.ORIGINAL,
  val resizeScale: Float = 1.0f,
  val originalWidth: Int = 0,
  val originalHeight: Int = 0,
)

data class PdfGenerationConfig(
  val fileName: String,
  val pageSize: PdfPageSize = PdfPageSize.A4,
  val orientation: PdfOrientation = PdfOrientation.PORTRAIT,
  val imageFit: PdfImageFit = PdfImageFit.PRESERVE_ASPECT,
  val quality: PdfQuality = PdfQuality.HIGH,
  val includeMargins: Boolean = true,
)

data class PdfDocumentRecord(
  val id: Long,
  val displayName: String,
  val filePath: String,
  val createdAt: Long,
  val pageCount: Int,
  val fileSizeBytes: Long,
  val thumbnailPath: String?,
  val fileExists: Boolean = true,
)

data class PdfInfoMetadata(
  val fileName: String,
  val pageCount: Int,
  val fileSizeBytes: Long,
  val pdfVersion: String,
  val title: String?,
  val author: String?,
  val creator: String?,
  val firstPageSizeText: String,
)

data class UserSettings(
  val themePreference: ThemePreference = ThemePreference.LIGHT,
  val defaultPageSize: PdfPageSize = PdfPageSize.A4,
  val defaultQuality: PdfQuality = PdfQuality.HIGH,
  val defaultNamingPrefix: String = "Pinkora_Document",
  val includeMargins: Boolean = true,
)
