package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.data.model.PdfGenerationConfig
import com.example.data.model.PdfImageFit
import com.example.data.model.PdfInfoMetadata
import com.example.data.model.PdfOrientation
import com.example.data.model.PdfPageSize
import com.example.data.model.PdfQuality
import com.example.data.model.ScannedPage
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

data class GeneratedPdfResult(
  val pdfFile: File,
  val thumbnailFile: File?,
  val pageCount: Int,
  val fileSizeBytes: Long,
)

object PdfEngine {

  suspend fun generatePdfFromPages(
    context: Context,
    pages: List<ScannedPage>,
    config: PdfGenerationConfig,
    outputPdfFile: File,
    outputThumbFile: File,
    onProgress: (current: Int, total: Int) -> Unit,
  ): Result<GeneratedPdfResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        if (pages.isEmpty()) error("No pages selected to create PDF.")

        val parentDir = outputPdfFile.parentFile
        if (parentDir != null) {
          parentDir.mkdirs()
          if (parentDir.usableSpace < 2L * 1024L * 1024L) {
            error("Insufficient device storage space to write PDF.")
          }
        }

        val tempFile = File(outputPdfFile.parentFile, "${outputPdfFile.name}.tmp")
        val document = PdfDocument()
        var firstThumbSaved = false

        try {
          pages.forEachIndexed { index, page ->
            coroutineContext.ensureActive()
            onProgress(index + 1, pages.size)

            val processed =
              ImageProcessor.renderProcessedBitmap(
                page = page,
                maxDimension = config.quality.maxDimensionPx,
                applyCrop = true,
              ) ?: error("Failed to decode page ${index + 1}.")

            // Recompress intermediate bitmap to respect selected quality & keep PDF compact
            val compressedBitmap =
              recompressBitmap(processed, config.quality.jpegQuality).also {
                if (it !== processed) processed.recycle()
              }

            val (pageWidth, pageHeight) = computePageDimensions(compressedBitmap, config)
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
            val pdfPage = document.startPage(pageInfo)

            val canvas = pdfPage.canvas
            canvas.drawColor(Color.WHITE)

            val marginPt = if (config.includeMargins && config.pageSize != PdfPageSize.ORIGINAL) 24f else 0f
            val availW = max(10f, pageWidth - marginPt * 2f)
            val availH = max(10f, pageHeight - marginPt * 2f)

            val dstRect = computeImageRect(
              imgW = compressedBitmap.width.toFloat(),
              imgH = compressedBitmap.height.toFloat(),
              margin = marginPt,
              availW = availW,
              availH = availH,
              fitMode = config.imageFit,
            )

            val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            canvas.drawBitmap(
              compressedBitmap,
              Rect(0, 0, compressedBitmap.width, compressedBitmap.height),
              dstRect,
              paint,
            )

            document.finishPage(pdfPage)

            if (!firstThumbSaved) {
              saveThumbnail(compressedBitmap, outputThumbFile)
              firstThumbSaved = true
            }
            compressedBitmap.recycle()
          }

          coroutineContext.ensureActive()
          FileOutputStream(tempFile).use { fos ->
            document.writeTo(fos)
            fos.flush()
          }
        } catch (t: Throwable) {
          tempFile.delete()
          throw t
        } finally {
          document.close()
        }

        if (!tempFile.exists() || tempFile.length() == 0L) {
          tempFile.delete()
          error("Generated PDF file was empty.")
        }

        val verifiedCount = verifyPdfPageCount(tempFile)
        if (verifiedCount <= 0) {
          tempFile.delete()
          error("Generated PDF could not be verified.")
        }

        if (outputPdfFile.exists()) outputPdfFile.delete()
        if (!tempFile.renameTo(outputPdfFile)) {
          tempFile.copyTo(outputPdfFile, overwrite = true)
          tempFile.delete()
        }

        GeneratedPdfResult(
          pdfFile = outputPdfFile,
          thumbnailFile = outputThumbFile.takeIf { it.exists() },
          pageCount = verifiedCount,
          fileSizeBytes = outputPdfFile.length(),
        )
      }
    }

  private fun computePageDimensions(bitmap: Bitmap, config: PdfGenerationConfig): Pair<Int, Int> {
    if (config.pageSize == PdfPageSize.ORIGINAL) {
      val scale = 720f / max(bitmap.width, bitmap.height).coerceAtLeast(1)
      val w = (bitmap.width * scale).roundToInt().coerceAtLeast(120)
      val h = (bitmap.height * scale).roundToInt().coerceAtLeast(120)
      return w to h
    }

    val shortSide = min(config.pageSize.widthPt, config.pageSize.heightPt)
    val longSide = max(config.pageSize.widthPt, config.pageSize.heightPt)

    return when (config.orientation) {
      PdfOrientation.PORTRAIT -> shortSide to longSide
      PdfOrientation.LANDSCAPE -> longSide to shortSide
    }
  }

  private fun computeImageRect(
    imgW: Float,
    imgH: Float,
    margin: Float,
    availW: Float,
    availH: Float,
    fitMode: PdfImageFit,
  ): RectF {
    val scale =
      when (fitMode) {
        PdfImageFit.FIT_TO_PAGE -> min(availW / imgW, availH / imgH)
        PdfImageFit.PRESERVE_ASPECT -> min(availW / imgW, availH / imgH)
      }
    val drawW = imgW * scale
    val drawH = imgH * scale
    val left = margin + (availW - drawW) / 2f
    val top = margin + (availH - drawH) / 2f
    return RectF(left, top, left + drawW, top + drawH)
  }

  private fun recompressBitmap(src: Bitmap, quality: Int): Bitmap {
    if (quality >= 92) return src
    val baos = ByteArrayOutputStream()
    src.compress(Bitmap.CompressFormat.JPEG, quality, baos)
    val bytes = baos.toByteArray()
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: src
  }

  fun saveThumbnail(bitmap: Bitmap, outFile: File) {
    outFile.parentFile?.mkdirs()
    val targetW = 360
    val ratio = targetW.toFloat() / max(1, bitmap.width)
    val targetH = max(60, (bitmap.height * ratio).roundToInt())
    val thumb = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    FileOutputStream(outFile).use { fos ->
      thumb.compress(Bitmap.CompressFormat.JPEG, 82, fos)
    }
    if (thumb !== bitmap) thumb.recycle()
  }

  fun verifyPdfPageCount(file: File): Int {
    if (!file.exists() || file.length() == 0L) return 0
    return runCatching {
      ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
        PdfRenderer(pfd).use { renderer -> renderer.pageCount }
      }
    }.getOrDefault(0)
  }

  fun generateThumbnailFromPdf(file: File, outThumb: File): File? {
    if (!file.exists() || file.length() == 0L) return null
    return runCatching {
      ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
        PdfRenderer(pfd).use { renderer ->
          if (renderer.pageCount <= 0) return null
          renderer.openPage(0).use { page ->
            val w = 360
            val h = max(80, (page.height.toFloat() / max(1, page.width) * w).roundToInt())
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(bmp).drawColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            saveThumbnail(bmp, outThumb)
            bmp.recycle()
            outThumb
          }
        }
      }
    }.getOrNull()
  }

  suspend fun mergePdfs(
    context: Context,
    inputUris: List<Uri>,
    outputFile: File,
    outputThumb: File,
  ): Result<GeneratedPdfResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        if (inputUris.size < 2) error("Select at least two PDF files to merge.")
        outputFile.parentFile?.mkdirs()
        val tempFiles = mutableListOf<File>()
        try {
          val merger = PDFMergerUtility()
          inputUris.forEachIndexed { idx, uri ->
            val tmp = File(context.cacheDir, "merge_in_$idx.pdf")
            context.contentResolver.openInputStream(uri)?.use { input ->
              FileOutputStream(tmp).use { output -> input.copyTo(output) }
            } ?: error("Could not read selected PDF #${idx + 1}.")
            tempFiles.add(tmp)
            merger.addSource(tmp)
          }
          FileOutputStream(outputFile).use { fos ->
            merger.destinationStream = fos
            merger.mergeDocuments(null)
          }
          val count = verifyPdfPageCount(outputFile)
          if (count <= 0) error("Merged PDF appears invalid.")
          val thumb = generateThumbnailFromPdf(outputFile, outputThumb)
          GeneratedPdfResult(outputFile, thumb, count, outputFile.length())
        } finally {
          tempFiles.forEach { it.delete() }
        }
      }
    }

  suspend fun splitOrExtractPdf(
    context: Context,
    inputUri: Uri,
    pageNumbers1Based: List<Int>,
    outputFile: File,
    outputThumb: File,
  ): Result<GeneratedPdfResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        if (pageNumbers1Based.isEmpty()) error("Select at least one page to extract.")
        outputFile.parentFile?.mkdirs()
        context.contentResolver.openInputStream(inputUri)?.use { stream ->
          PDDocument.load(stream).use { srcDoc ->
            val total = srcDoc.numberOfPages
            val validPages = pageNumbers1Based.distinct().filter { it in 1..total }
            if (validPages.isEmpty()) error("Selected page numbers are out of range (1..$total).")
            PDDocument().use { dstDoc ->
              validPages.forEach { pageNum ->
                dstDoc.importPage(srcDoc.getPage(pageNum - 1))
              }
              FileOutputStream(outputFile).use { fos -> dstDoc.save(fos) }
            }
          }
        } ?: error("Unable to open the source PDF.")

        val count = verifyPdfPageCount(outputFile)
        if (count <= 0) error("Extracted PDF could not be verified.")
        val thumb = generateThumbnailFromPdf(outputFile, outputThumb)
        GeneratedPdfResult(outputFile, thumb, count, outputFile.length())
      }
    }

  suspend fun rotatePdfPages(
    context: Context,
    inputUri: Uri,
    rotationDeltaDegrees: Int,
    outputFile: File,
    outputThumb: File,
  ): Result<GeneratedPdfResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        outputFile.parentFile?.mkdirs()
        context.contentResolver.openInputStream(inputUri)?.use { stream ->
          PDDocument.load(stream).use { doc ->
            for (i in 0 until doc.numberOfPages) {
              val page = doc.getPage(i)
              val nextRotation = ((page.rotation + rotationDeltaDegrees) % 360 + 360) % 360
              page.rotation = nextRotation
            }
            FileOutputStream(outputFile).use { fos -> doc.save(fos) }
          }
        } ?: error("Unable to open the selected PDF.")

        val count = verifyPdfPageCount(outputFile)
        if (count <= 0) error("Rotated PDF could not be verified.")
        val thumb = generateThumbnailFromPdf(outputFile, outputThumb)
        GeneratedPdfResult(outputFile, thumb, count, outputFile.length())
      }
    }

  suspend fun compressPdf(
    context: Context,
    inputUri: Uri,
    quality: PdfQuality,
    outputFile: File,
    outputThumb: File,
    onProgress: (Int, Int) -> Unit,
  ): Result<GeneratedPdfResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        outputFile.parentFile?.mkdirs()
        val tempIn = File(context.cacheDir, "compress_src.pdf")
        context.contentResolver.openInputStream(inputUri)?.use { input ->
          FileOutputStream(tempIn).use { output -> input.copyTo(output) }
        } ?: error("Unable to open selected PDF.")

        try {
          val outPdf = PdfDocument()
          var thumbSaved = false
          try {
            ParcelFileDescriptor.open(tempIn, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
              PdfRenderer(pfd).use { renderer ->
                val total = renderer.pageCount
                if (total <= 0) error("Selected PDF has no pages.")
                for (i in 0 until total) {
                  coroutineContext.ensureActive()
                  onProgress(i + 1, total)
                  renderer.openPage(i).use { page ->
                    val maxEdge = quality.maxDimensionPx.coerceAtMost(1750)
                    val scale = min(2.0f, maxEdge.toFloat() / max(page.width, page.height).coerceAtLeast(1))
                    val bmpW = max(120, (page.width * scale).roundToInt())
                    val bmpH = max(120, (page.height * scale).roundToInt())
                    val rawBmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                    Canvas(rawBmp).drawColor(Color.WHITE)
                    page.render(rawBmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                    val compressed = recompressBitmap(rawBmp, quality.jpegQuality)
                    if (compressed !== rawBmp) rawBmp.recycle()

                    val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, i + 1).create()
                    val pdfPage = outPdf.startPage(pageInfo)
                    pdfPage.canvas.drawBitmap(
                      compressed,
                      Rect(0, 0, compressed.width, compressed.height),
                      RectF(0f, 0f, page.width.toFloat(), page.height.toFloat()),
                      Paint(Paint.FILTER_BITMAP_FLAG),
                    )
                    outPdf.finishPage(pdfPage)
                    if (!thumbSaved) {
                      saveThumbnail(compressed, outputThumb)
                      thumbSaved = true
                    }
                    compressed.recycle()
                  }
                }
              }
            }
            FileOutputStream(outputFile).use { fos ->
              outPdf.writeTo(fos)
              fos.flush()
            }
          } finally {
            outPdf.close()
          }
          val count = verifyPdfPageCount(outputFile)
          if (count <= 0) error("Compressed PDF could not be verified.")
          GeneratedPdfResult(outputFile, outputThumb.takeIf { it.exists() }, count, outputFile.length())
        } finally {
          tempIn.delete()
        }
      }
    }

  suspend fun inspectPdfInfo(context: Context, uri: Uri, displayName: String): Result<PdfInfoMetadata> =
    withContext(Dispatchers.IO) {
      runCatching {
        val fileSize =
          context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length.coerceAtLeast(0L) } ?: 0L
        context.contentResolver.openInputStream(uri)?.use { stream ->
          PDDocument.load(stream).use { doc ->
            val info = doc.documentInformation
            val firstPage = if (doc.numberOfPages > 0) doc.getPage(0).mediaBox else null
            val dims =
              if (firstPage != null) {
                "${firstPage.width.roundToInt()} × ${firstPage.height.roundToInt()} pt"
              } else {
                "Unknown"
              }
            PdfInfoMetadata(
              fileName = displayName,
              pageCount = doc.numberOfPages,
              fileSizeBytes = fileSize,
              pdfVersion = doc.version.toString(),
              title = info?.title?.takeIf { it.isNotBlank() },
              author = info?.author?.takeIf { it.isNotBlank() },
              creator = info?.creator?.takeIf { it.isNotBlank() },
              firstPageSizeText = dims,
            )
          }
        } ?: error("Could not read PDF file.")
      }
    }
}
