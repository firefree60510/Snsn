package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.example.data.model.CropRect
import com.example.data.model.ResizePreset
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedPage
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ImageProcessor {

  private const val MAX_IMPORT_DIMENSION = 2400

  suspend fun importUriToScanPage(
    context: Context,
    uri: Uri,
    runAutoEdgeDetect: Boolean = true,
  ): Result<ScannedPage> =
    withContext(Dispatchers.IO) {
      runCatching {
        val scansDir = File(context.cacheDir, "scans").apply { mkdirs() }
        val outFile = File(scansDir, "scan_${UUID.randomUUID()}.jpg")

        val decoded = decodeSampledBitmapFromUri(context, uri, MAX_IMPORT_DIMENSION)
          ?: error("Unsupported or unreadable image file.")

        val exifRotation = readExifRotation(context, uri)
        val orientedBitmap =
          if (exifRotation != 0) {
            rotateBitmap(decoded, exifRotation).also {
              if (it !== decoded) decoded.recycle()
            }
          } else {
            decoded
          }

        FileOutputStream(outFile).use { fos ->
          orientedBitmap.compress(Bitmap.CompressFormat.JPEG, 94, fos)
        }

        val width = orientedBitmap.width
        val height = orientedBitmap.height

        val autoCrop =
          if (runAutoEdgeDetect) {
            detectDocumentEdges(orientedBitmap)
          } else {
            CropRect()
          }

        orientedBitmap.recycle()

        ScannedPage(
          sourceFilePath = outFile.absolutePath,
          rotationDegrees = 0,
          cropRect = autoCrop,
          autoDetectedCropRect = autoCrop,
          filter = ScanFilter.ORIGINAL,
          resizePreset = ResizePreset.ORIGINAL,
          resizeScale = 1.0f,
          originalWidth = width,
          originalHeight = height,
        )
      }
    }

  suspend fun createPageFromFile(
    file: File,
    runAutoEdgeDetect: Boolean = true,
  ): Result<ScannedPage> =
    withContext(Dispatchers.IO) {
      runCatching {
        val decoded = decodeSampledBitmapFromFile(file, MAX_IMPORT_DIMENSION)
          ?: error("Unable to read captured image.")
        val exifRotation = readExifRotationFromFile(file)
        val oriented =
          if (exifRotation != 0) {
            rotateBitmap(decoded, exifRotation).also {
              if (it !== decoded) decoded.recycle()
            }
          } else {
            decoded
          }

        if (exifRotation != 0) {
          FileOutputStream(file).use { fos ->
            oriented.compress(Bitmap.CompressFormat.JPEG, 94, fos)
          }
        }

        val width = oriented.width
        val height = oriented.height
        val autoCrop = if (runAutoEdgeDetect) detectDocumentEdges(oriented) else CropRect()
        oriented.recycle()

        ScannedPage(
          sourceFilePath = file.absolutePath,
          rotationDegrees = 0,
          cropRect = autoCrop,
          autoDetectedCropRect = autoCrop,
          filter = ScanFilter.ORIGINAL,
          resizePreset = ResizePreset.ORIGINAL,
          resizeScale = 1.0f,
          originalWidth = width,
          originalHeight = height,
        )
      }
    }

  /**
   * Automatic document boundary detector using downsampled edge-energy & paper-luminance
   * projection. Detects document rectangle inside background desk/surface while staying safe
   * when an image is already tightly framed.
   */
  fun detectDocumentEdges(bitmap: Bitmap): CropRect {
    val targetW = 160
    val scale = targetW.toFloat() / max(1, bitmap.width)
    val targetH = max(40, (bitmap.height * scale).roundToInt())
    val small = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)

    return try {
      val pixels = IntArray(targetW * targetH)
      small.getPixels(pixels, 0, targetW, 0, 0, targetW, targetH)

      val luma = FloatArray(targetW * targetH)
      for (i in pixels.indices) {
        val c = pixels[i]
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        luma[i] = 0.299f * r + 0.587f * g + 0.114f * b
      }

      // Compute border luminance median estimate
      var borderSum = 0f
      var borderCount = 0
      for (x in 0 until targetW) {
        borderSum += luma[x]
        borderSum += luma[(targetH - 1) * targetW + x]
        borderCount += 2
      }
      for (y in 1 until targetH - 1) {
        borderSum += luma[y * targetW]
        borderSum += luma[y * targetW + (targetW - 1)]
        borderCount += 2
      }
      val borderMean = borderSum / max(1, borderCount)

      // Compute row and column edge energy + bright paper mask
      val rowEnergy = FloatArray(targetH)
      val colEnergy = FloatArray(targetW)
      var totalCenterLuma = 0f
      var centerCount = 0

      for (y in 1 until targetH - 1) {
        for (x in 1 until targetW - 1) {
          val idx = y * targetW + x
          val gx = abs(luma[idx + 1] - luma[idx - 1])
          val gy = abs(luma[idx + targetW] - luma[idx - targetW])
          val edge = gx + gy
          rowEnergy[y] += edge
          colEnergy[x] += edge
          if (x in (targetW / 4)..(3 * targetW / 4) && y in (targetH / 4)..(3 * targetH / 4)) {
            totalCenterLuma += luma[idx]
            centerCount++
          }
        }
      }

      val centerMean = totalCenterLuma / max(1, centerCount)
      val contrastDelta = centerMean - borderMean

      // If center is significantly brighter than border (e.g. paper on desk), refine bounds
      if (contrastDelta > 18f) {
        val threshold = borderMean + contrastDelta * 0.42f
        var minX = targetW
        var maxX = 0
        var minY = targetH
        var maxY = 0
        var hitCount = 0

        for (y in 2 until targetH - 2) {
          for (x in 2 until targetW - 2) {
            if (luma[y * targetW + x] >= threshold) {
              minX = min(minX, x)
              maxX = max(maxX, x)
              minY = min(minY, y)
              maxY = max(maxY, y)
              hitCount++
            }
          }
        }

        val boxW = maxX - minX
        val boxH = maxY - minY
        if (hitCount > (targetW * targetH * 0.15f) && boxW > targetW * 0.35f && boxH > targetH * 0.35f) {
          val padX = 0.015f
          val padY = 0.015f
          val l = ((minX.toFloat() / targetW) - padX).coerceIn(0f, 0.35f)
          val r = ((maxX.toFloat() / targetW) + padX).coerceIn(0.65f, 1f)
          val t = ((minY.toFloat() / targetH) - padY).coerceIn(0f, 0.35f)
          val b = ((maxY.toFloat() / targetH) + padY).coerceIn(0.65f, 1f)
          return CropRect(left = l, top = t, right = r, bottom = b)
        }
      }

      // Secondary edge-energy peak scan along outer 30% bands
      val avgCol = colEnergy.average().toFloat()
      val avgRow = rowEnergy.average().toFloat()
      var leftIdx = 0
      var rightIdx = targetW - 1
      var topIdx = 0
      var bottomIdx = targetH - 1

      for (x in 2 until (targetW * 0.32f).toInt()) {
        if (colEnergy[x] > avgCol * 1.45f) {
          leftIdx = x
          break
        }
      }
      for (x in targetW - 3 downTo (targetW * 0.68f).toInt()) {
        if (colEnergy[x] > avgCol * 1.45f) {
          rightIdx = x
          break
        }
      }
      for (y in 2 until (targetH * 0.32f).toInt()) {
        if (rowEnergy[y] > avgRow * 1.45f) {
          topIdx = y
          break
        }
      }
      for (y in targetH - 3 downTo (targetH * 0.68f).toInt()) {
        if (rowEnergy[y] > avgRow * 1.45f) {
          bottomIdx = y
          break
        }
      }

      val l = (leftIdx.toFloat() / targetW).coerceIn(0f, 0.30f)
      val r = (rightIdx.toFloat() / targetW).coerceIn(0.70f, 1f)
      val t = (topIdx.toFloat() / targetH).coerceIn(0f, 0.30f)
      val b = (bottomIdx.toFloat() / targetH).coerceIn(0.70f, 1f)

      if ((r - l) >= 0.45f && (b - t) >= 0.45f) {
        CropRect(left = l, top = t, right = r, bottom = b)
      } else {
        CropRect()
      }
    } catch (_: Throwable) {
      CropRect()
    } finally {
      if (small !== bitmap) small.recycle()
    }
  }

  suspend fun renderProcessedBitmap(
    page: ScannedPage,
    maxDimension: Int,
    applyCrop: Boolean = true,
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      val file = File(page.sourceFilePath)
      if (!file.exists()) return@withContext null

      val base = decodeSampledBitmapFromFile(file, maxDimension) ?: return@withContext null

      // Step 1: Rotate first if needed
      val rotated =
        if (page.rotationDegrees % 360 != 0) {
          rotateBitmap(base, page.rotationDegrees).also {
            if (it !== base) base.recycle()
          }
        } else {
          base
        }

      // Step 2: Apply CropRect & ResizePreset aspect adjustment
      val cropped =
        if (applyCrop && !page.cropRect.isFull) {
          cropNormalized(rotated, page.cropRect).also {
            if (it !== rotated) rotated.recycle()
          }
        } else {
          rotated
        }

      // Step 3: Apply ResizePreset aspect / resizeScale
      val resized =
        applyResize(cropped, page.resizePreset, page.resizeScale).also {
          if (it !== cropped) cropped.recycle()
        }

      // Step 4: Apply Filter
      if (page.filter == ScanFilter.ORIGINAL) {
        resized
      } else {
        applyFilter(resized, page.filter).also {
          if (it !== resized) resized.recycle()
        }
      }
    }

  private fun cropNormalized(src: Bitmap, crop: CropRect): Bitmap {
    val x = (crop.left * src.width).roundToInt().coerceIn(0, max(0, src.width - 2))
    val y = (crop.top * src.height).roundToInt().coerceIn(0, max(0, src.height - 2))
    val w = ((crop.right - crop.left) * src.width).roundToInt().coerceIn(1, src.width - x)
    val h = ((crop.bottom - crop.top) * src.height).roundToInt().coerceIn(1, src.height - y)
    if (x == 0 && y == 0 && w == src.width && h == src.height) return src
    return Bitmap.createBitmap(src, x, y, w, h)
  }

  private fun applyResize(src: Bitmap, preset: ResizePreset, scaleFactor: Float): Bitmap {
    val clampedScale = scaleFactor.coerceIn(0.35f, 1.0f)
    val targetRatio = preset.aspectRatio

    val aspectAdjusted =
      if (targetRatio != null) {
        val currentRatio = src.width.toFloat() / max(1, src.height)
        if (abs(currentRatio - targetRatio) > 0.02f) {
          // Center crop cleanly to target aspect ratio without stretching
          if (currentRatio > targetRatio) {
            val newW = (src.height * targetRatio).roundToInt().coerceIn(1, src.width)
            val startX = (src.width - newW) / 2
            Bitmap.createBitmap(src, startX, 0, newW, src.height)
          } else {
            val newH = (src.width / targetRatio).roundToInt().coerceIn(1, src.height)
            val startY = (src.height - newH) / 2
            Bitmap.createBitmap(src, 0, startY, src.width, newH)
          }
        } else {
          src
        }
      } else {
        src
      }

    return if (clampedScale < 0.99f) {
      val dstW = max(16, (aspectAdjusted.width * clampedScale).roundToInt())
      val dstH = max(16, (aspectAdjusted.height * clampedScale).roundToInt())
      val scaled = Bitmap.createScaledBitmap(aspectAdjusted, dstW, dstH, true)
      if (aspectAdjusted !== src && scaled !== aspectAdjusted) {
        aspectAdjusted.recycle()
      }
      scaled
    } else {
      aspectAdjusted
    }
  }

  fun applyFilter(src: Bitmap, filter: ScanFilter): Bitmap {
    if (filter == ScanFilter.ORIGINAL) return src

    if (filter == ScanFilter.BLACK_WHITE) {
      return applyBlackAndWhiteDocumentFilter(src)
    }

    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val matrix = ColorMatrix()

    when (filter) {
      ScanFilter.ENHANCED -> {
        val contrast = 1.24f
        val brightness = -18f
        val contrastMatrix =
          ColorMatrix(
            floatArrayOf(
              contrast, 0f, 0f, 0f, brightness,
              0f, contrast, 0f, 0f, brightness,
              0f, 0f, contrast, 0f, brightness,
              0f, 0f, 0f, 1f, 0f,
            )
          )
        val sat = ColorMatrix().apply { setSaturation(1.18f) }
        matrix.postConcat(sat)
        matrix.postConcat(contrastMatrix)
      }
      ScanFilter.GRAYSCALE -> {
        matrix.setSaturation(0f)
        val contrast = 1.15f
        val shift = -12f
        val cMatrix =
          ColorMatrix(
            floatArrayOf(
              contrast, 0f, 0f, 0f, shift,
              0f, contrast, 0f, 0f, shift,
              0f, 0f, contrast, 0f, shift,
              0f, 0f, 0f, 1f, 0f,
            )
          )
        matrix.postConcat(cMatrix)
      }
      ScanFilter.HIGH_CONTRAST -> {
        matrix.setSaturation(0.25f)
        val contrast = 1.65f
        val shift = -55f
        val cMatrix =
          ColorMatrix(
            floatArrayOf(
              contrast, 0f, 0f, 0f, shift,
              0f, contrast, 0f, 0f, shift,
              0f, 0f, contrast, 0f, shift,
              0f, 0f, 0f, 1f, 0f,
            )
          )
        matrix.postConcat(cMatrix)
      }
      ScanFilter.ORIGINAL, ScanFilter.BLACK_WHITE -> Unit
    }

    paint.colorFilter = ColorMatrixColorFilter(matrix)
    canvas.drawBitmap(src, 0f, 0f, paint)
    return out
  }

  private fun applyBlackAndWhiteDocumentFilter(src: Bitmap): Bitmap {
    val w = src.width
    val h = src.height
    val pixels = IntArray(w * h)
    src.getPixels(pixels, 0, w, 0, 0, w, h)

    // Compute histogram to find Otsu-like adaptive threshold
    val hist = IntArray(256)
    val gray = IntArray(w * h)
    for (i in pixels.indices) {
      val c = pixels[i]
      val r = (c shr 16) and 0xFF
      val g = (c shr 8) and 0xFF
      val b = c and 0xFF
      val y = ((77 * r + 150 * g + 29 * b) shr 8).coerceIn(0, 255)
      gray[i] = y
      hist[y]++
    }

    val total = pixels.size
    var sum = 0L
    for (t in 0..255) sum += t.toLong() * hist[t]
    var sumB = 0L
    var wB = 0
    var maxVar = 0.0
    var threshold = 135

    for (t in 0..255) {
      wB += hist[t]
      if (wB == 0) continue
      val wF = total - wB
      if (wF == 0) break
      sumB += t.toLong() * hist[t]
      val mB = sumB.toDouble() / wB
      val mF = (sum - sumB).toDouble() / wF
      val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
      if (between > maxVar) {
        maxVar = between
        threshold = t
      }
    }

    val adjustedThreshold = (threshold * 0.94f).roundToInt().coerceIn(75, 200)
    for (i in pixels.indices) {
      val v = gray[i]
      val outGray =
        when {
          v < adjustedThreshold - 18 -> 18
          v > adjustedThreshold + 18 -> 252
          else -> ((v - (adjustedThreshold - 18)) * 234 / 36).coerceIn(18, 252)
        }
      pixels[i] = (0xFF shl 24) or (outGray shl 16) or (outGray shl 8) or outGray
    }

    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(pixels, 0, w, 0, 0, w, h)
    return out
  }

  fun rotateBitmap(bitmap: Bitmap, degrees: Int): Bitmap {
    val normalized = ((degrees % 360) + 360) % 360
    if (normalized == 0) return bitmap
    val matrix = Matrix().apply { postRotate(normalized.toFloat()) }
    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
  }

  fun decodeSampledBitmapFromUri(context: Context, uri: Uri, maxDimension: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { stream ->
      BitmapFactory.decodeStream(stream, null, bounds)
    } ?: return null

    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    val sampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, maxDimension)
    val opts =
      BitmapFactory.Options().apply {
        inSampleSize = sampleSize
        inPreferredConfig = Bitmap.Config.ARGB_8888
      }
    return context.contentResolver.openInputStream(uri)?.use { stream ->
      BitmapFactory.decodeStream(stream, null, opts)
    }
  }

  fun decodeSampledBitmapFromFile(file: File, maxDimension: Int): Bitmap? {
    if (!file.exists()) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    val opts =
      BitmapFactory.Options().apply {
        inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, maxDimension)
        inPreferredConfig = Bitmap.Config.ARGB_8888
      }
    return BitmapFactory.decodeFile(file.absolutePath, opts)
  }

  private fun calculateInSampleSize(width: Int, height: Int, maxDim: Int): Int {
    var inSampleSize = 1
    var longest = max(width, height)
    while (longest / inSampleSize > maxDim) {
      inSampleSize *= 2
    }
    return inSampleSize
  }

  private fun readExifRotation(context: Context, uri: Uri): Int {
    return runCatching {
      context.contentResolver.openInputStream(uri)?.use { stream ->
        val exif = ExifInterface(stream)
        exifToDegrees(exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL))
      } ?: 0
    }.getOrDefault(0)
  }

  private fun readExifRotationFromFile(file: File): Int {
    return runCatching {
      val exif = ExifInterface(file.absolutePath)
      exifToDegrees(exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL))
    }.getOrDefault(0)
  }

  private fun exifToDegrees(orientation: Int): Int {
    return when (orientation) {
      ExifInterface.ORIENTATION_ROTATE_90 -> 90
      ExifInterface.ORIENTATION_ROTATE_180 -> 180
      ExifInterface.ORIENTATION_ROTATE_270 -> 270
      else -> 0
    }
  }
}
