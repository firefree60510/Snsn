package com.example.ads

import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * Policy-compliant anchored Banner Ad placed at the bottom of main tabs with safe spacing
 * away from forms and primary action buttons. Collapses cleanly when unavailable.
 */
@Composable
fun PinkoraBannerAd(modifier: Modifier = Modifier) {
  var isLoaded by remember { mutableStateOf(false) }

  Surface(
    modifier =
      modifier
        .fillMaxWidth()
        .then(
          if (isLoaded) Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
          else Modifier.height(0.dp)
        ),
    color = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(12.dp),
    border = if (isLoaded) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null,
  ) {
    Box(
      modifier = Modifier.fillMaxWidth().padding(vertical = if (isLoaded) 2.dp else 0.dp),
      contentAlignment = Alignment.Center,
    ) {
      BannerAdViewHolder(onLoaded = { isLoaded = it })
    }
  }
}

@Composable
private fun BannerAdViewHolder(onLoaded: (Boolean) -> Unit) {
  val context = LocalContext.current
  val sdkReady by AdMobConfig.isSdkInitialized.collectAsState()
  if (!sdkReady) return

  val adView = remember {
    runCatching {
      AdView(context).apply {
        setAdSize(AdSize.BANNER)
        adUnitId = AdMobConfig.BANNER_AD_UNIT_ID
        adListener =
          object : AdListener() {
            override fun onAdLoaded() {
              onLoaded(true)
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
              onLoaded(false)
            }
          }
        loadAd(AdRequest.Builder().build())
      }
    }.getOrNull()
  }

  DisposableEffect(adView) {
    onDispose { runCatching { adView?.destroy() } }
  }

  if (adView != null) {
    AndroidView(
      factory = { adView },
      modifier = Modifier.fillMaxWidth(),
    )
  }
}

/**
 * Native Ad card blended naturally into Home / My Files lists with clear "Ad" attribution badge
 * and generous margins to prevent accidental taps.
 */
@Composable
fun PinkoraNativeAdCard(modifier: Modifier = Modifier) {
  val context = LocalContext.current
  val sdkReady by AdMobConfig.isSdkInitialized.collectAsState()
  var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

  DisposableEffect(sdkReady) {
    if (!sdkReady) {
      return@DisposableEffect onDispose {}
    }
    var active = true
    runCatching {
      val loader =
        AdLoader.Builder(context, AdMobConfig.NATIVE_AD_UNIT_ID)
          .forNativeAd { ad ->
            if (active) {
              nativeAd?.destroy()
              nativeAd = ad
            } else {
              ad.destroy()
            }
          }
          .build()
      loader.loadAd(AdRequest.Builder().build())
    }
    onDispose {
      active = false
      runCatching { nativeAd?.destroy() }
    }
  }

  val loadedAd = nativeAd ?: return

  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
  ) {
    AndroidView(
      modifier = Modifier.fillMaxWidth().padding(12.dp),
      factory = { ctx ->
        val view = LayoutInflater.from(ctx).inflate(R.layout.view_pinkora_native_ad, null) as NativeAdView
        view
      },
      update = { adView ->
        val headline = adView.findViewById<TextView>(R.id.ad_headline)
        val body = adView.findViewById<TextView>(R.id.ad_body)
        val cta = adView.findViewById<Button>(R.id.ad_call_to_action)
        val icon = adView.findViewById<ImageView>(R.id.ad_app_icon)

        adView.headlineView = headline
        adView.bodyView = body
        adView.callToActionView = cta
        adView.iconView = icon

        headline.text = loadedAd.headline
        body.text = loadedAd.body ?: ""
        body.visibility = if (loadedAd.body.isNullOrBlank()) View.GONE else View.VISIBLE

        if (loadedAd.callToAction != null) {
          cta.visibility = View.VISIBLE
          cta.text = loadedAd.callToAction
        } else {
          cta.visibility = View.GONE
        }

        val iconDrawable = loadedAd.icon?.drawable
        if (iconDrawable != null) {
          icon.visibility = View.VISIBLE
          icon.setImageDrawable(iconDrawable)
        } else {
          icon.visibility = View.GONE
        }

        adView.setNativeAd(loadedAd)
      },
    )
  }
}
