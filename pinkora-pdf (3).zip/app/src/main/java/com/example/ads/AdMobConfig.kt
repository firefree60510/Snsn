package com.example.ads

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Official Google AdMob Test Ad Unit IDs.
 *
 * BEFORE PUBLISHING TO GOOGLE PLAY:
 * Replace these test IDs with your own AdMob Ad Unit IDs from https://admob.google.com,
 * and replace `com.google.android.gms.ads.APPLICATION_ID` in AndroidManifest.xml with your real App ID.
 */
object AdMobConfig {
  const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
  const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
  const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
  const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
  const val NATIVE_AD_UNIT_ID = "ca-app-pub-3940256099942544/2247696110"

  private val _isSdkInitialized = MutableStateFlow(false)
  val isSdkInitialized: StateFlow<Boolean> = _isSdkInitialized.asStateFlow()

  fun markSdkInitialized() {
    _isSdkInitialized.value = true
  }
}
