package com.example.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages AdMob Interstitial and Rewarded ads with safe preloading, frequency capping,
 * and graceful fallback when offline or unavailable.
 */
class PinkoraAdManager(private val appContext: Context) {

  private var rewardedAd: RewardedAd? = null
  private var isLoadingRewarded = false

  private var interstitialAd: InterstitialAd? = null
  private var isLoadingInterstitial = false

  // Natural-break counter: only show interstitial once every 3-4 completed flows
  private var completedActionsSinceInterstitial = 0
  private var lastInterstitialShownAtMs = 0L

  private val _rewardedReady = MutableStateFlow(false)
  val rewardedReady: StateFlow<Boolean> = _rewardedReady.asStateFlow()

  fun preloadAll() {
    preloadRewarded()
    preloadInterstitial()
  }

  fun preloadRewarded() {
    if (!AdMobConfig.isSdkInitialized.value || rewardedAd != null || isLoadingRewarded) return
    isLoadingRewarded = true
    runCatching {
      RewardedAd.load(
        appContext,
        AdMobConfig.REWARDED_AD_UNIT_ID,
        AdRequest.Builder().build(),
        object : RewardedAdLoadCallback() {
          override fun onAdLoaded(ad: RewardedAd) {
            isLoadingRewarded = false
            rewardedAd = ad
            _rewardedReady.value = true
          }

          override fun onAdFailedToLoad(error: LoadAdError) {
            isLoadingRewarded = false
            rewardedAd = null
            _rewardedReady.value = false
          }
        },
      )
    }.onFailure {
      isLoadingRewarded = false
      _rewardedReady.value = false
    }
  }

  fun preloadInterstitial() {
    if (!AdMobConfig.isSdkInitialized.value || interstitialAd != null || isLoadingInterstitial) return
    isLoadingInterstitial = true
    runCatching {
      InterstitialAd.load(
        appContext,
        AdMobConfig.INTERSTITIAL_AD_UNIT_ID,
        AdRequest.Builder().build(),
        object : InterstitialAdLoadCallback() {
          override fun onAdLoaded(ad: InterstitialAd) {
            isLoadingInterstitial = false
            interstitialAd = ad
          }

          override fun onAdFailedToLoad(error: LoadAdError) {
            isLoadingInterstitial = false
            interstitialAd = null
          }
        },
      )
    }.onFailure { isLoadingInterstitial = false }
  }

  /**
   * Shows the Rewarded Ad before final PDF generation/download.
   * Calls [onRewardEarned] once the user finishes watching the ad.
   * Calls [onAdUnavailable] if no ad is loaded (caller presents Retry / Continue fallback).
   * Calls [onAdDismissedWithoutReward] if the user closed the ad early.
   */
  fun showRewardedForPdfExport(
    activity: Activity?,
    onRewardEarned: () -> Unit,
    onAdUnavailable: () -> Unit,
    onAdDismissedWithoutReward: () -> Unit,
  ) {
    val ad = rewardedAd
    if (activity == null || ad == null) {
      preloadRewarded()
      onAdUnavailable()
      return
    }

    var rewardGranted = false
    rewardedAd = null
    _rewardedReady.value = false

    ad.fullScreenContentCallback =
      object : FullScreenContentCallback() {
        override fun onAdDismissedFullScreenContent() {
          preloadRewarded()
          if (rewardGranted) {
            onRewardEarned()
          } else {
            onAdDismissedWithoutReward()
          }
        }

        override fun onAdFailedToShowFullScreenContent(error: AdError) {
          preloadRewarded()
          onAdUnavailable()
        }
      }

    ad.show(activity) {
      rewardGranted = true
    }
  }

  /**
   * Call on natural breaks (e.g., after closing PDF Viewer or completing a Tool flow).
   * Only shows once every 3-4 actions and never back-to-back (< 45s cooldown).
   */
  fun maybeShowInterstitialAtNaturalBreak(activity: Activity?, onContinue: () -> Unit) {
    completedActionsSinceInterstitial++
    val elapsed = System.currentTimeMillis() - lastInterstitialShownAtMs
    val shouldShow = completedActionsSinceInterstitial >= 3 && elapsed >= 45_000L

    val ad = interstitialAd
    if (!shouldShow || activity == null || ad == null) {
      if (ad == null) preloadInterstitial()
      onContinue()
      return
    }

    completedActionsSinceInterstitial = 0
    lastInterstitialShownAtMs = System.currentTimeMillis()
    interstitialAd = null

    ad.fullScreenContentCallback =
      object : FullScreenContentCallback() {
        override fun onAdDismissedFullScreenContent() {
          preloadInterstitial()
          onContinue()
        }

        override fun onAdFailedToShowFullScreenContent(error: AdError) {
          preloadInterstitial()
          onContinue()
        }
      }
    ad.show(activity)
  }
}
