package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ads.PinkoraBannerAd
import com.example.data.model.PdfDocumentRecord
import com.example.ui.components.PinkoraBrandMark
import com.example.ui.components.findActivity
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyFilesScreen
import com.example.ui.screens.PageEditorScreen
import com.example.ui.screens.PdfViewerScreen
import com.example.ui.screens.ScannerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.theme.PinkoraPdfTheme

object PinkoraRoutes {
  const val HOME = "home"
  const val MY_FILES = "my_files"
  const val TOOLS = "tools"
  const val SETTINGS = "settings"
  const val SCANNER = "scanner"
  const val EDITOR = "editor"
  const val VIEWER = "viewer/{docId}"

  fun viewerRoute(docId: Long): String = "viewer/$docId"
}

private data class BottomTab(
  val route: String,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val tag: String,
)

@Composable
fun PinkoraApp(viewModel: PinkoraViewModel = viewModel()) {
  val context = LocalContext.current
  val activity = remember(context) { context.findActivity() }
  val navController = rememberNavController()
  val snackbarHostState = remember { SnackbarHostState() }

  val settings by viewModel.settings.collectAsStateWithLifecycle()
  val allDocuments by viewModel.allDocuments.collectAsStateWithLifecycle()
  val filteredDocuments by viewModel.filteredDocuments.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()
  val isGridView by viewModel.isGridView.collectAsStateWithLifecycle()

  val sessionPages by viewModel.sessionPages.collectAsStateWithLifecycle()
  val selectedPageIndex by viewModel.selectedPageIndex.collectAsStateWithLifecycle()
  val isImporting by viewModel.isImportingImages.collectAsStateWithLifecycle()
  val pdfCreationState by viewModel.pdfCreationState.collectAsStateWithLifecycle()
  val toolState by viewModel.toolState.collectAsStateWithLifecycle()

  var showCreateSourceDialog by remember { mutableStateOf(false) }
  var pendingExportRecord by remember { mutableStateOf<PdfDocumentRecord?>(null) }
  var appendOnGalleryPick by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    viewModel.snackbarMessages.collect { msg ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  val galleryPickerLauncher =
    rememberLauncherForActivityResult(
      ActivityResultContracts.PickMultipleVisualMedia(maxItems = 40)
    ) { uris: List<Uri> ->
      if (uris.isNotEmpty()) {
        val shouldAppend = appendOnGalleryPick
        viewModel.importGalleryUris(uris, append = shouldAppend) { success ->
          if (success) {
            navController.navigate(PinkoraRoutes.EDITOR) {
              launchSingleTop = true
            }
          }
        }
      }
    }

  val importPdfLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        viewModel.importExternalPdf(uri)
      }
    }

  val exportPdfLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { destUri ->
      val target = pendingExportRecord
      pendingExportRecord = null
      if (destUri != null && target != null) {
        viewModel.exportDocumentToUri(target, destUri)
      }
    }

  fun launchGalleryPicker(append: Boolean) {
    appendOnGalleryPick = append
    galleryPickerLauncher.launch(
      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
    )
  }

  fun shareDocument(record: PdfDocumentRecord) {
    val intent = viewModel.documentRepository.buildShareIntent(record)
    if (intent != null) {
      runCatching { context.startActivity(intent) }.onFailure {
        viewModel.postMessage("No compatible app found to share PDF.")
      }
    } else {
      viewModel.postMessage("Cannot share: PDF file is missing.")
    }
  }

  fun openExternalDocument(record: PdfDocumentRecord) {
    val intent = viewModel.documentRepository.buildOpenExternalIntent(record)
    if (intent != null) {
      runCatching { context.startActivity(intent) }.onFailure {
        viewModel.postMessage("No external PDF viewer app found.")
      }
    } else {
      viewModel.postMessage("PDF file is missing.")
    }
  }

  fun saveCopyToDevice(record: PdfDocumentRecord) {
    pendingExportRecord = record
    exportPdfLauncher.launch(record.displayName)
  }

  val tabs =
    listOf(
      BottomTab(PinkoraRoutes.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
      BottomTab(PinkoraRoutes.MY_FILES, "My Files", Icons.Filled.Folder, Icons.Outlined.Folder, "nav_files"),
      BottomTab(PinkoraRoutes.TOOLS, "Tools", Icons.Filled.Build, Icons.Outlined.Build, "nav_tools"),
      BottomTab(PinkoraRoutes.SETTINGS, "Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "nav_settings"),
    )

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = navBackStackEntry?.destination
  val currentRoute = currentDestination?.route
  val isMainTabRoute = currentRoute in tabs.map { it.route }

  PinkoraPdfTheme(themePreference = settings.themePreference) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val useNavRail = maxWidth >= 600.dp && isMainTabRoute

      Row(modifier = Modifier.fillMaxSize()) {
        if (useNavRail) {
          NavigationRail(
            containerColor = MaterialTheme.colorScheme.surface,
            header = {
              Spacer(modifier = Modifier.height(12.dp))
              PinkoraBrandMark(size = 38.dp)
              Spacer(modifier = Modifier.height(12.dp))
            },
            modifier = Modifier.fillMaxHeight(),
          ) {
            tabs.forEach { tab ->
              val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
              NavigationRailItem(
                selected = selected,
                onClick = {
                  navController.navigate(tab.route) {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                  }
                },
                icon = {
                  Icon(
                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                    contentDescription = tab.label,
                  )
                },
                label = { Text(tab.label) },
                colors =
                  NavigationRailItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                  ),
                modifier = Modifier.testTag(tab.tag),
              )
            }
          }
        }

        Scaffold(
          modifier = Modifier.weight(1f).fillMaxSize(),
          containerColor = MaterialTheme.colorScheme.background,
          contentWindowInsets =
            if (isMainTabRoute) WindowInsets.safeDrawing else WindowInsets(0, 0, 0, 0),
          snackbarHost = { SnackbarHost(snackbarHostState) },
          floatingActionButton = {
            if (currentRoute == PinkoraRoutes.HOME || currentRoute == PinkoraRoutes.MY_FILES) {
              FloatingActionButton(
                onClick = { navController.navigate(PinkoraRoutes.SCANNER) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("fab_scan_document"),
              ) {
                Icon(Icons.Default.DocumentScanner, contentDescription = "Scan Document")
              }
            }
          },
          bottomBar = {
            if (isMainTabRoute) {
              Column(
                modifier =
                  Modifier.fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding(),
              ) {
                // Anchored Banner Ad cleanly separated above navigation bar (zero button overlap)
                PinkoraBannerAd()

                if (!useNavRail) {
                  NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                  ) {
                    tabs.forEach { tab ->
                      val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                      NavigationBarItem(
                        selected = selected,
                        onClick = {
                          navController.navigate(tab.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                          }
                        },
                        icon = {
                          Icon(
                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = tab.label,
                          )
                        },
                        label = {
                          Text(
                            text = tab.label,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                          )
                        },
                        colors =
                          NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                          ),
                        modifier = Modifier.testTag(tab.tag),
                      )
                    }
                  }
                }
              }
            }
          },
        ) { innerPadding ->
          NavHost(
            navController = navController,
            startDestination = PinkoraRoutes.HOME,
            modifier =
              Modifier.fillMaxSize()
                .let { mod -> if (isMainTabRoute) mod.padding(innerPadding) else mod },
          ) {
            composable(PinkoraRoutes.HOME) {
              HomeScreen(
                recentDocuments = allDocuments,
                onOpenGalleryPicker = { launchGalleryPicker(append = false) },
                onOpenScanner = {
                  viewModel.clearSession()
                  navController.navigate(PinkoraRoutes.SCANNER)
                },
                onOpenCreateSourceDialog = { showCreateSourceDialog = true },
                onOpenMyFiles = {
                  navController.navigate(PinkoraRoutes.MY_FILES) {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                  }
                },
                onOpenSettings = {
                  navController.navigate(PinkoraRoutes.SETTINGS) {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                  }
                },
                onOpenDocument = { doc -> navController.navigate(PinkoraRoutes.viewerRoute(doc.id)) },
                onShareDocument = { doc -> shareDocument(doc) },
                onRenameDocument = { doc, newName -> viewModel.renameDocument(doc, newName) },
                onDeleteDocument = { doc -> viewModel.deleteDocument(doc) },
                onRemoveStaleRecord = { id -> viewModel.removeStaleDocument(id) },
              )
            }

            composable(PinkoraRoutes.MY_FILES) {
              MyFilesScreen(
                documents = filteredDocuments,
                searchQuery = searchQuery,
                sortOption = sortOption,
                isGridView = isGridView,
                onSearchChange = viewModel::setSearchQuery,
                onSortChange = viewModel::setSortOption,
                onToggleView = viewModel::toggleGridView,
                onImportExternalPdf = { importPdfLauncher.launch(arrayOf("application/pdf")) },
                onCreateFirstPdf = { showCreateSourceDialog = true },
                onOpenDocument = { doc -> navController.navigate(PinkoraRoutes.viewerRoute(doc.id)) },
                onShareDocument = { doc -> shareDocument(doc) },
                onRenameDocument = { doc, newName -> viewModel.renameDocument(doc, newName) },
                onDeleteDocument = { doc -> viewModel.deleteDocument(doc) },
                onRemoveStaleRecord = { id -> viewModel.removeStaleDocument(id) },
              )
            }

            composable(PinkoraRoutes.TOOLS) {
              ToolsScreen(
                savedDocuments = allDocuments,
                toolState = toolState,
                onStartImagesToPdf = { launchGalleryPicker(append = false) },
                onMergePdfs = viewModel::mergePdfs,
                onSplitOrExtractPdf = viewModel::splitOrExtractPdf,
                onRotatePdf = viewModel::rotatePdf,
                onCompressPdf = viewModel::compressPdf,
                onInspectPdf = viewModel::inspectPdfInfo,
                onRenameDocument = { doc, name -> viewModel.renameDocument(doc, name) },
                onShareDocument = { doc -> shareDocument(doc) },
                onOpenGeneratedDocument = { doc ->
                  viewModel.adManager.maybeShowInterstitialAtNaturalBreak(activity) {
                    navController.navigate(PinkoraRoutes.viewerRoute(doc.id))
                  }
                },
                onResetToolState = viewModel::resetToolState,
              )
            }

            composable(PinkoraRoutes.SETTINGS) {
              SettingsScreen(
                settings = settings,
                documents = allDocuments,
                onUpdateTheme = viewModel::updateTheme,
                onUpdateDefaultPageSize = viewModel::updateDefaultPageSize,
                onUpdateDefaultQuality = viewModel::updateDefaultQuality,
                onUpdateNamingPrefix = viewModel::updateDefaultNamingPrefix,
                onUpdateIncludeMargins = viewModel::updateIncludeMargins,
                onShowMessage = viewModel::postMessage,
              )
            }

            composable(PinkoraRoutes.SCANNER) {
              ScannerScreen(
                existingPageCount = sessionPages.size,
                onCaptureAccepted = { file, keepScanning ->
                  viewModel.addCapturedFile(file, append = true) { ok ->
                    if (ok && !keepScanning) {
                      navController.navigate(PinkoraRoutes.EDITOR) {
                        popUpTo(PinkoraRoutes.SCANNER) { inclusive = true }
                        launchSingleTop = true
                      }
                    }
                  }
                },
                onOpenGalleryFromScanner = {
                  launchGalleryPicker(append = sessionPages.isNotEmpty())
                },
                onFinishScanning = {
                  navController.navigate(PinkoraRoutes.EDITOR) {
                    popUpTo(PinkoraRoutes.SCANNER) { inclusive = true }
                    launchSingleTop = true
                  }
                },
                onClose = { navController.popBackStack() },
              )
            }

            composable(PinkoraRoutes.EDITOR) {
              PageEditorScreen(
                pages = sessionPages,
                selectedPageIndex = selectedPageIndex,
                settings = settings,
                suggestedFileName = remember(allDocuments.size, settings.defaultNamingPrefix) {
                  viewModel.suggestPdfName()
                },
                pdfCreationState = pdfCreationState,
                onSelectPage = viewModel::selectPage,
                onRotatePage = viewModel::rotateSelectedPage,
                onUpdateCrop = viewModel::updateSelectedCrop,
                onAutoDetectCrop = viewModel::applyAutoEdgeCropToSelected,
                onResetCrop = viewModel::resetSelectedCrop,
                onUpdateFilter = viewModel::updateSelectedFilter,
                onApplyFilterToAll = viewModel::applyFilterToAllPages,
                onUpdateResize = viewModel::updateSelectedResize,
                onMovePage = viewModel::movePage,
                onDuplicatePage = viewModel::duplicateSelectedPage,
                onDeletePage = viewModel::deletePage,
                onAddFromGallery = { launchGalleryPicker(append = true) },
                onAddFromCamera = { navController.navigate(PinkoraRoutes.SCANNER) },
                onCreatePdfRequested = { config ->
                  viewModel.requestPdfGenerationWithRewardedAd(activity, config)
                },
                onContinueWithoutAd = { config -> viewModel.executePdfGeneration(config) },
                onRetryAdAndGenerate = { config ->
                  viewModel.requestPdfGenerationWithRewardedAd(activity, config)
                },
                onCancelGeneration = viewModel::cancelPdfGeneration,
                onResetCreationState = viewModel::resetPdfCreationState,
                onOpenGeneratedPdf = { doc ->
                  viewModel.resetPdfCreationState()
                  viewModel.clearSession()
                  navController.navigate(PinkoraRoutes.viewerRoute(doc.id)) {
                    popUpTo(PinkoraRoutes.HOME)
                  }
                },
                onShareGeneratedPdf = { doc -> shareDocument(doc) },
                onSaveCopyGeneratedPdf = { doc -> saveCopyToDevice(doc) },
                onRenameGeneratedPdf = { doc, newName -> viewModel.renameDocument(doc, newName) },
                onExitToHome = {
                  viewModel.clearSession()
                  viewModel.resetPdfCreationState()
                  viewModel.adManager.maybeShowInterstitialAtNaturalBreak(activity) {
                    navController.popBackStack(PinkoraRoutes.HOME, inclusive = false)
                  }
                },
              )
            }

            composable(
              route = PinkoraRoutes.VIEWER,
              arguments = listOf(navArgument("docId") { type = NavType.LongType }),
            ) { entry ->
              val docId = entry.arguments?.getLong("docId") ?: -1L
              val doc = allDocuments.find { it.id == docId }
              PdfViewerScreen(
                document = doc,
                onBack = {
                  viewModel.adManager.maybeShowInterstitialAtNaturalBreak(activity) {
                    navController.popBackStack()
                  }
                },
                onShare = { d -> shareDocument(d) },
                onSaveCopy = { d -> saveCopyToDevice(d) },
                onOpenExternal = { d -> openExternalDocument(d) },
              )
            }
          }
        }
      }

      // Source picker dialog when user taps "Create PDF" or "Create your first PDF"
      if (showCreateSourceDialog) {
        AlertDialog(
          onDismissRequest = { showCreateSourceDialog = false },
          title = { Text("Create PDF From") },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(
                "Select images from your gallery or scan physical documents with your camera.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Button(
                onClick = {
                  showCreateSourceDialog = false
                  launchGalleryPicker(append = false)
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("source_gallery_button"),
              ) {
                Icon(Icons.Default.Collections, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Gallery Photos")
              }
              OutlinedButton(
                onClick = {
                  showCreateSourceDialog = false
                  viewModel.clearSession()
                  navController.navigate(PinkoraRoutes.SCANNER)
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("source_camera_button"),
              ) {
                Icon(Icons.Default.DocumentScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Scan Document")
              }
            }
          },
          confirmButton = {},
          dismissButton = {
            TextButton(onClick = { showCreateSourceDialog = false }) { Text("Cancel") }
          },
        )
      }

      // Busy overlay during image import
      if (isImporting) {
        Box(
          modifier =
            Modifier.fillMaxSize()
              .background(MaterialTheme.colorScheme.background.copy(alpha = 0.72f)),
          contentAlignment = Alignment.Center,
        ) {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              CircularProgressIndicator()
              Text("Preparing pages & detecting edges…", style = MaterialTheme.typography.bodyMedium)
            }
          }
        }
      }
    }
  }
}
