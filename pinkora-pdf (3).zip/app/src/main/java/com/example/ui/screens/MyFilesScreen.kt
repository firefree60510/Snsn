package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.ads.PinkoraNativeAdCard
import com.example.data.model.PdfDocumentRecord
import com.example.data.model.PdfSortOption
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DocumentDetailsDialog
import com.example.ui.components.EmptyDocumentsState
import com.example.ui.components.PdfDocumentRowCard
import com.example.ui.components.RenamePdfDialog
import com.example.ui.components.formatFileSize
import java.io.File

@Composable
fun MyFilesScreen(
  documents: List<PdfDocumentRecord>,
  searchQuery: String,
  sortOption: PdfSortOption,
  isGridView: Boolean,
  onSearchChange: (String) -> Unit,
  onSortChange: (PdfSortOption) -> Unit,
  onToggleView: () -> Unit,
  onImportExternalPdf: () -> Unit,
  onCreateFirstPdf: () -> Unit,
  onOpenDocument: (PdfDocumentRecord) -> Unit,
  onShareDocument: (PdfDocumentRecord) -> Unit,
  onRenameDocument: (PdfDocumentRecord, String) -> Unit,
  onDeleteDocument: (PdfDocumentRecord) -> Unit,
  onRemoveStaleRecord: (Long) -> Unit,
  modifier: Modifier = Modifier,
) {
  var sortMenuOpen by remember { mutableStateOf(false) }
  var renameTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }
  var deleteTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }
  var detailsTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }

  BoxWithConstraints(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    val gridColumns = if (maxWidth >= 600.dp) 3 else 2

    Column(
      modifier = Modifier.widthIn(max = 840.dp).fillMaxSize().padding(horizontal = 16.dp),
    ) {
      Spacer(modifier = Modifier.height(14.dp))

      // Top Header Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column {
          Text(
            text = "My Files",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = "${documents.size} ${if (documents.size == 1) "document" else "documents"} saved locally",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          OutlinedButton(
            onClick = onImportExternalPdf,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.height(42.dp).testTag("import_pdf_button"),
          ) {
            Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Import")
          }

          IconButton(
            onClick = onToggleView,
            modifier = Modifier.testTag("toggle_view_button"),
          ) {
            Icon(
              imageVector = if (isGridView) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
              contentDescription = if (isGridView) "Switch to list view" else "Switch to grid view",
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Search & Sort Controls
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = onSearchChange,
          placeholder = { Text("Search PDFs by name…") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchChange("") }) {
                Icon(Icons.Default.Close, contentDescription = "Clear search")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.weight(1f).testTag("files_search_input"),
        )

        Box {
          FilterChip(
            selected = false,
            onClick = { sortMenuOpen = true },
            label = { Text(sortOption.label.substringBefore(" ")) },
            leadingIcon = {
              Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort options", modifier = Modifier.size(18.dp))
            },
            modifier = Modifier.height(52.dp).testTag("files_sort_button"),
          )
          DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
            PdfSortOption.entries.forEach { option ->
              DropdownMenuItem(
                text = { Text(option.label) },
                onClick = {
                  sortMenuOpen = false
                  onSortChange(option)
                },
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (documents.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
          if (searchQuery.isNotBlank()) {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            ) {
              Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Text("No matching PDFs", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  "No saved document matches \"$searchQuery\".",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          } else {
            EmptyDocumentsState(
              onCreateFirstPdf = onCreateFirstPdf,
              modifier = Modifier.padding(top = 12.dp),
            )
          }
        }
      } else if (isGridView) {
        LazyVerticalGrid(
          columns = GridCells.Fixed(gridColumns),
          verticalArrangement = Arrangement.spacedBy(12.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          contentPadding = PaddingValues(bottom = 16.dp),
          modifier = Modifier.fillMaxSize(),
        ) {
          items(documents, key = { it.id }) { doc ->
            PdfGridCard(
              document = doc,
              onOpen = { onOpenDocument(doc) },
              onShare = { onShareDocument(doc) },
              onRename = { renameTarget = doc },
              onDelete = { deleteTarget = doc },
            )
          }
          item(span = { GridItemSpan(gridColumns) }) {
            PinkoraNativeAdCard(modifier = Modifier.padding(top = 4.dp))
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 16.dp),
          modifier = Modifier.fillMaxSize(),
        ) {
          itemsIndexed(documents, key = { _, doc -> doc.id }) { index, doc ->
            PdfDocumentRowCard(
              document = doc,
              onOpen = { onOpenDocument(doc) },
              onShare = { onShareDocument(doc) },
              onRename = { renameTarget = doc },
              onDelete = { deleteTarget = doc },
              onDetails = { detailsTarget = doc },
              onRemoveStale = { onRemoveStaleRecord(doc.id) },
            )
            // Place native ad cleanly after 2nd item or at end if fewer
            if (index == 1 || (documents.size == 1 && index == 0)) {
              Spacer(modifier = Modifier.height(10.dp))
              PinkoraNativeAdCard()
            }
          }
        }
      }
    }
  }

  renameTarget?.let { target ->
    RenamePdfDialog(
      currentName = target.displayName,
      onConfirm = { newName ->
        renameTarget = null
        onRenameDocument(target, newName)
      },
      onDismiss = { renameTarget = null },
    )
  }

  deleteTarget?.let { target ->
    ConfirmDeleteDialog(
      title = "Delete PDF?",
      message = "Permanently delete \"${target.displayName}\" from your device?",
      onConfirm = {
        deleteTarget = null
        onDeleteDocument(target)
      },
      onDismiss = { deleteTarget = null },
    )
  }

  detailsTarget?.let { target ->
    DocumentDetailsDialog(
      document = target,
      onDismiss = { detailsTarget = null },
      onOpen = { onOpenDocument(target) },
      onShare = { onShareDocument(target) },
    )
  }
}

@Composable
private fun PdfGridCard(
  document: PdfDocumentRecord,
  onOpen: () -> Unit,
  onShare: () -> Unit,
  onRename: () -> Unit,
  onDelete: () -> Unit,
) {
  var menuOpen by remember { mutableStateOf(false) }

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .clickable(onClick = onOpen),
    shape = RoundedCornerShape(18.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .aspectRatio(0.85f)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
      ) {
        if (document.thumbnailPath != null && document.fileExists) {
          AsyncImage(
            model = File(document.thumbnailPath),
            contentDescription = "Preview of ${document.displayName}",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
          )
        } else {
          Icon(
            imageVector = Icons.Default.PictureAsPdf,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(38.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = document.displayName,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = "${document.pageCount}p • ${formatFileSize(document.fileSizeBytes)}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
          )
        }

        Box {
          IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.MoreVert, contentDescription = "Document options")
          }
          DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(text = { Text("Open") }, onClick = { menuOpen = false; onOpen() })
            DropdownMenuItem(text = { Text("Share") }, onClick = { menuOpen = false; onShare() })
            DropdownMenuItem(text = { Text("Rename") }, onClick = { menuOpen = false; onRename() })
            DropdownMenuItem(
              text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
              onClick = { menuOpen = false; onDelete() },
            )
          }
        }
      }
    }
  }
}
