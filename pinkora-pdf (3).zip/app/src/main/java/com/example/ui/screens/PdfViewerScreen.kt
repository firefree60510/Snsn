package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.PdfDocumentRecord
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun PdfViewerScreen(
  document: PdfDocumentRecord?,
  onBack: () -> Unit,
  onShare: (PdfDocumentRecord) -> Unit,
  onSaveCopy: (PdfDocumentRecord) -> Unit,
  onOpenExternal: (PdfDocumentRecord) -> Unit,
) {
  BackHandler { onBack() }

  var currentPageIndex by remember { mutableIntStateOf(0) }
  var totalPages by remember { mutableIntStateOf(0) }
  var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var isLoading by remember { mutableStateOf(true) }
  var errorMsg by remember { mutableStateOf<String?>(null) }

  var zoom by remember { mutableFloatStateOf(1f) }
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(document?.filePath, currentPageIndex) {
    if (document == null) {
      errorMsg = "Document could not be found."
      isLoading = false
      return@LaunchedEffect
    }
    val file = File(document.filePath)
    if (!file.exists() || file.length() == 0L) {
      errorMsg = "This PDF file was moved or deleted."
      isLoading = false
      return@LaunchedEffect
    }

    isLoading = true
    errorMsg = null
    val result =
      withContext(Dispatchers.IO) {
        runCatching {
          ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
              val count = renderer.pageCount
              if (count <= 0) error("This PDF contains zero readable pages.")
              val safeIdx = currentPageIndex.coerceIn(0, count - 1)
              renderer.openPage(safeIdx).use { page ->
                val targetW = 1440
                val scale = targetW.toFloat() / max(1, page.width)
                val targetH = max(200, (page.height * scale).roundToInt())
                val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                Canvas(bmp).drawColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                count to bmp
              }
            }
          }
        }
      }

    result
      .onSuccess { (count, bmp) ->
        totalPages = count
        pageBitmap?.recycle()
        pageBitmap = bmp
        isLoading = false
      }
      .onFailure { err ->
        errorMsg = err.message ?: "Unable to render this PDF file."
        isLoading = false
      }
  }

  DisposableEffect(Unit) {
    onDispose {
      pageBitmap?.recycle()
      pageBitmap = null
    }
  }

  Column(
    modifier =
      Modifier.fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .statusBarsPadding()
        .navigationBarsPadding(),
  ) {
    // Top Toolbar
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("viewer_back_button")) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = document?.displayName ?: "PDF Viewer",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          if (totalPages > 0) {
            Text(
              text = "Page ${currentPageIndex + 1} of $totalPages • ${(zoom * 100).roundToInt()}%",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }

        if (document != null && errorMsg == null) {
          IconButton(onClick = { onSaveCopy(document) }, modifier = Modifier.testTag("viewer_save_copy")) {
            Icon(Icons.Default.Download, contentDescription = "Save copy to device")
          }
          IconButton(onClick = { onShare(document) }, modifier = Modifier.testTag("viewer_share_button")) {
            Icon(Icons.Default.Share, contentDescription = "Share PDF")
          }
          IconButton(onClick = { onOpenExternal(document) }) {
            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Open with external app")
          }
        }
      }
    }

    // Main PDF Page Viewport with Pinch-to-Zoom & Double-Tap Reset
    Box(
      modifier =
        Modifier.weight(1f)
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceContainerHigh)
          .pointerInput(Unit) {
            detectTransformGestures { _, pan, zoomChange, _ ->
              val nextZoom = (zoom * zoomChange).coerceIn(1f, 4f)
              zoom = nextZoom
              if (nextZoom > 1f) {
                offsetX += pan.x
                offsetY += pan.y
              } else {
                offsetX = 0f
                offsetY = 0f
              }
            }
          }
          .pointerInput(Unit) {
            detectTapGestures(
              onDoubleTap = {
                if (zoom > 1.05f) {
                  zoom = 1f
                  offsetX = 0f
                  offsetY = 0f
                } else {
                  zoom = 2f
                }
              }
            )
          },
      contentAlignment = Alignment.Center,
    ) {
      when {
        isLoading -> CircularProgressIndicator()
        errorMsg != null -> {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.padding(24.dp),
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(
                Icons.Outlined.ErrorOutline,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(40.dp),
              )
              Text("Unable to Open PDF", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              Text(
                errorMsg ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
              )
              Button(onClick = onBack) { Text("Back to Files") }
            }
          }
        }
        pageBitmap != null -> {
          Surface(
            shape = RoundedCornerShape(10.dp),
            shadowElevation = 4.dp,
            color = androidx.compose.ui.graphics.Color.White,
            modifier =
              Modifier.fillMaxSize()
                .padding(16.dp)
                .graphicsLayer(
                  scaleX = zoom,
                  scaleY = zoom,
                  translationX = offsetX,
                  translationY = offsetY,
                ),
          ) {
            Image(
              bitmap = pageBitmap!!.asImageBitmap(),
              contentDescription = "PDF page ${currentPageIndex + 1}",
              modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)),
              contentScale = ContentScale.Fit,
            )
          }
        }
      }
    }

    // Bottom Page Navigation Bar
    if (totalPages > 0 && errorMsg == null) {
      Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          OutlinedButton(
            enabled = currentPageIndex > 0,
            onClick = {
              zoom = 1f
              offsetX = 0f
              offsetY = 0f
              currentPageIndex--
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.height(44.dp),
          ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = null)
            Text("Prev")
          }

          Text(
            text = "${currentPageIndex + 1} / $totalPages",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
          )

          OutlinedButton(
            enabled = currentPageIndex < totalPages - 1,
            onClick = {
              zoom = 1f
              offsetX = 0f
              offsetY = 0f
              currentPageIndex++
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.height(44.dp),
          ) {
            Text("Next")
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
          }
        }
      }
    }
  }
}
