package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.RotateLeft
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterBAndW
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.CropRect
import com.example.data.model.PdfDocumentRecord
import com.example.data.model.PdfGenerationConfig
import com.example.data.model.PdfImageFit
import com.example.data.model.PdfOrientation
import com.example.data.model.PdfPageSize
import com.example.data.model.PdfQuality
import com.example.data.model.ResizePreset
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedPage
import com.example.data.model.UserSettings
import com.example.engine.ImageProcessor
import com.example.ui.PdfCreationUiState
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.RenamePdfDialog
import com.example.ui.components.findActivity
import com.example.ui.components.formatFileSize
import java.io.File
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

private enum class EditorToolTab(val label: String) {
  CROP("Crop"),
  ROTATE("Rotate"),
  FILTERS("Filters"),
  RESIZE("Resize"),
  ORDER("Pages"),
}

private enum class DragCorner {
  TOP_LEFT,
  TOP_RIGHT,
  BOTTOM_LEFT,
  BOTTOM_RIGHT,
}

@Composable
fun PageEditorScreen(
  pages: List<ScannedPage>,
  selectedPageIndex: Int,
  settings: UserSettings,
  suggestedFileName: String,
  pdfCreationState: PdfCreationUiState,
  onSelectPage: (Int) -> Unit,
  onRotatePage: (Int) -> Unit,
  onUpdateCrop: (CropRect) -> Unit,
  onAutoDetectCrop: () -> Unit,
  onResetCrop: () -> Unit,
  onUpdateFilter: (ScanFilter) -> Unit,
  onApplyFilterToAll: (ScanFilter) -> Unit,
  onUpdateResize: (ResizePreset, Float) -> Unit,
  onMovePage: (Int, Int) -> Unit,
  onDuplicatePage: () -> Unit,
  onDeletePage: (Int) -> Unit,
  onAddFromGallery: () -> Unit,
  onAddFromCamera: () -> Unit,
  onCreatePdfRequested: (PdfGenerationConfig) -> Unit,
  onContinueWithoutAd: (PdfGenerationConfig) -> Unit,
  onRetryAdAndGenerate: (PdfGenerationConfig) -> Unit,
  onCancelGeneration: () -> Unit,
  onResetCreationState: () -> Unit,
  onOpenGeneratedPdf: (PdfDocumentRecord) -> Unit,
  onShareGeneratedPdf: (PdfDocumentRecord) -> Unit,
  onSaveCopyGeneratedPdf: (PdfDocumentRecord) -> Unit,
  onRenameGeneratedPdf: (PdfDocumentRecord, String) -> Unit,
  onExitToHome: () -> Unit,
) {
  val context = LocalContext.current
  val activity = remember(context) { context.findActivity() }

  var activeTab by remember { mutableStateOf(EditorToolTab.CROP) }
  var isManualCropping by remember { mutableStateOf(false) }
  var showSettingsDialog by remember { mutableStateOf(false) }
  var showDiscardConfirm by remember { mutableStateOf(false) }
  var pendingDeleteIndex by remember { mutableStateOf<Int?>(null) }
  var renameSuccessTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }

  val currentPage = pages.getOrNull(selectedPageIndex)

  BackHandler {
    when {
      isManualCropping -> isManualCropping = false
      pdfCreationState is PdfCreationUiState.Success -> {
        onResetCreationState()
        onExitToHome()
      }
      pages.isNotEmpty() -> showDiscardConfirm = true
      else -> onExitToHome()
    }
  }

  // Success screen state
  if (pdfCreationState is PdfCreationUiState.Success) {
    PdfCreationSuccessScreen(
      document = pdfCreationState.document,
      onOpen = { onOpenGeneratedPdf(pdfCreationState.document) },
      onShare = { onShareGeneratedPdf(pdfCreationState.document) },
      onSaveCopy = { onSaveCopyGeneratedPdf(pdfCreationState.document) },
      onRename = { renameSuccessTarget = pdfCreationState.document },
      onReturnHome = {
        onResetCreationState()
        onExitToHome()
      },
    )

    renameSuccessTarget?.let { target ->
      RenamePdfDialog(
        currentName = target.displayName,
        onConfirm = { newName ->
          renameSuccessTarget = null
          onRenameGeneratedPdf(target, newName)
        },
        onDismiss = { renameSuccessTarget = null },
      )
    }
    return
  }

  // Empty guard
  if (pages.isEmpty() || currentPage == null) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(MaterialTheme.colorScheme.background)
          .statusBarsPadding()
          .navigationBarsPadding()
          .padding(24.dp),
      contentAlignment = Alignment.Center,
    ) {
      Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Text("No Pages Selected", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
          Text(
            "Add photos from your gallery or scan a physical document to build a PDF.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onAddFromGallery, modifier = Modifier.height(48.dp)) {
              Text("Gallery")
            }
            Button(onClick = onAddFromCamera, modifier = Modifier.height(48.dp)) {
              Text("Scan")
            }
          }
          TextButton(onClick = onExitToHome) { Text("Return Home") }
        }
      }
    }
    return
  }

  // Render live processed bitmap for the large fitted preview
  var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var isRenderingPreview by remember { mutableStateOf(false) }

  LaunchedEffect(
    currentPage.id,
    currentPage.rotationDegrees,
    currentPage.cropRect,
    currentPage.filter,
    currentPage.resizePreset,
    currentPage.resizeScale,
    isManualCropping,
  ) {
    isRenderingPreview = true
    val rendered =
      ImageProcessor.renderProcessedBitmap(
        page = currentPage,
        maxDimension = 1280,
        applyCrop = !isManualCropping,
      )
    previewBitmap?.recycle()
    previewBitmap = rendered
    isRenderingPreview = false
  }

  DisposableEffect(Unit) {
    onDispose {
      previewBitmap?.recycle()
      previewBitmap = null
    }
  }

  Column(
    modifier =
      Modifier.fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .statusBarsPadding()
        .navigationBarsPadding(),
  ) {
    // Top Editor Bar
    Surface(
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 2.dp,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = { showDiscardConfirm = true }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
          Column {
            Text(
              text = "Page ${selectedPageIndex + 1} of ${pages.size}",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = "${currentPage.filter.label} • ${(currentPage.resizeScale * 100).roundToInt()}%",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(onClick = onAddFromCamera, modifier = Modifier.testTag("editor_add_camera")) {
            Icon(Icons.Default.AddAPhoto, contentDescription = "Add page from camera")
          }
          IconButton(onClick = onAddFromGallery, modifier = Modifier.testTag("editor_add_gallery")) {
            Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add pages from gallery")
          }
          Button(
            onClick = {
              isManualCropping = false
              showSettingsDialog = true
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.height(42.dp).testTag("editor_create_pdf_button"),
          ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Create PDF")
          }
        }
      }
    }

    // Large, Clear, Properly Fitted Preview Canvas
    Box(
      modifier =
        Modifier.weight(1f)
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceContainerHigh)
          .padding(horizontal = 16.dp, vertical = 12.dp),
      contentAlignment = Alignment.Center,
    ) {
      val bmp = previewBitmap
      if (bmp != null) {
        if (isManualCropping) {
          InteractiveCropCanvas(
            bitmap = bmp,
            cropRect = currentPage.cropRect,
            onCropChange = onUpdateCrop,
            modifier = Modifier.fillMaxSize(),
          )
        } else {
          Surface(
            shape = RoundedCornerShape(14.dp),
            shadowElevation = 4.dp,
            color = Color.White,
            modifier = Modifier.wrapContentSizeSafe(),
          ) {
            Image(
              bitmap = bmp.asImageBitmap(),
              contentDescription = "Edited preview of page ${selectedPageIndex + 1}",
              modifier = Modifier.fillMaxSize().padding(4.dp),
              contentScale = ContentScale.Fit,
            )
          }
        }
      }

      if (isRenderingPreview) {
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
          modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
        ) {
          CircularProgressIndicator(
            modifier = Modifier.size(26.dp).padding(5.dp),
            strokeWidth = 2.5.dp,
          )
        }
      }
    }

    // Bottom Arranged Workspace: Thumbnail Strip + Tool Tabs + Active Controls
    Surface(
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 4.dp,
      shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 10.dp),
      ) {
        // Thumbnail Strip for Reordering & Selection
        LazyRow(
          contentPadding = PaddingValues(horizontal = 14.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          itemsIndexed(pages, key = { _, p -> p.id }) { idx, page ->
            val selected = idx == selectedPageIndex
            Box(
              modifier =
                Modifier.size(width = 56.dp, height = 70.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .border(
                    width = if (selected) 2.5.dp else 1.dp,
                    color =
                      if (selected) MaterialTheme.colorScheme.primary
                      else MaterialTheme.colorScheme.outlineVariant,
                    shape = RoundedCornerShape(10.dp),
                  )
                  .clickable {
                    isManualCropping = false
                    onSelectPage(idx)
                  }
                  .testTag("page_thumb_$idx"),
            ) {
              AsyncImage(
                model = File(page.sourceFilePath),
                contentDescription = "Thumbnail page ${idx + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
              )
              Surface(
                color =
                  if (selected) MaterialTheme.colorScheme.primary
                  else Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(bottomEnd = 8.dp),
              ) {
                Text(
                  text = "${idx + 1}",
                  style = MaterialTheme.typography.labelSmall,
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tool Category Pills
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .horizontalScroll(rememberScrollState())
              .padding(horizontal = 14.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          EditorToolTab.entries.forEach { tab ->
            val isSelected = activeTab == tab
            FilterChip(
              selected = isSelected,
              onClick = {
                activeTab = tab
                isManualCropping = (tab == EditorToolTab.CROP && isManualCropping)
              },
              label = { Text(tab.label) },
              leadingIcon = {
                Icon(
                  imageVector =
                    when (tab) {
                      EditorToolTab.CROP -> Icons.Default.Crop
                      EditorToolTab.ROTATE -> Icons.AutoMirrored.Filled.RotateRight
                      EditorToolTab.FILTERS -> Icons.Default.FilterBAndW
                      EditorToolTab.RESIZE -> Icons.Default.AspectRatio
                      EditorToolTab.ORDER -> Icons.Default.SwapHoriz
                    },
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                )
              },
              modifier = Modifier.testTag("editor_tab_${tab.name}"),
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Active Tool Controls Area
        Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
          when (activeTab) {
            EditorToolTab.CROP -> {
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Button(
                  onClick = {
                    isManualCropping = false
                    onAutoDetectCrop()
                  },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(44.dp).testTag("auto_crop_button"),
                ) {
                  Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Auto Edges")
                }

                OutlinedButton(
                  onClick = { isManualCropping = !isManualCropping },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(44.dp).testTag("manual_crop_toggle"),
                ) {
                  Icon(
                    if (isManualCropping) Icons.Default.Check else Icons.Default.Crop,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (isManualCropping) "Apply Crop" else "Manual Crop")
                }

                OutlinedButton(
                  onClick = {
                    isManualCropping = false
                    onResetCrop()
                  },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(44.dp),
                ) {
                  Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Reset")
                }
              }
            }

            EditorToolTab.ROTATE -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                OutlinedButton(
                  onClick = { onRotatePage(-90) },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f).height(46.dp).testTag("rotate_left_button"),
                ) {
                  Icon(Icons.AutoMirrored.Filled.RotateLeft, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Rotate Left")
                }
                OutlinedButton(
                  onClick = { onRotatePage(90) },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f).height(46.dp).testTag("rotate_right_button"),
                ) {
                  Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Rotate Right")
                }
              }
            }

            EditorToolTab.FILTERS -> {
              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  ScanFilter.entries.forEach { filter ->
                    FilterChip(
                      selected = currentPage.filter == filter,
                      onClick = { onUpdateFilter(filter) },
                      label = { Text(filter.label) },
                      modifier = Modifier.testTag("filter_chip_${filter.name}"),
                    )
                  }
                }
                if (pages.size > 1) {
                  TextButton(
                    onClick = { onApplyFilterToAll(currentPage.filter) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                  ) {
                    Text("Apply \"${currentPage.filter.label}\" to all ${pages.size} pages")
                  }
                }
              }
            }

            EditorToolTab.RESIZE -> {
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  ResizePreset.entries.forEach { preset ->
                    FilterChip(
                      selected = currentPage.resizePreset == preset,
                      onClick = { onUpdateResize(preset, currentPage.resizeScale) },
                      label = { Text(preset.label) },
                      modifier = Modifier.testTag("resize_preset_${preset.name}"),
                    )
                  }
                }
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Text(
                    text = "Scale: ${(currentPage.resizeScale * 100).roundToInt()}%",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.width(86.dp),
                  )
                  Slider(
                    value = currentPage.resizeScale,
                    onValueChange = { onUpdateResize(currentPage.resizePreset, it) },
                    valueRange = 0.4f..1.0f,
                    modifier = Modifier.weight(1f),
                  )
                }
              }
            }

            EditorToolTab.ORDER -> {
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                OutlinedButton(
                  enabled = selectedPageIndex > 0,
                  onClick = { onMovePage(selectedPageIndex, selectedPageIndex - 1) },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(44.dp).testTag("move_page_left"),
                ) {
                  Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Move Left")
                }
                OutlinedButton(
                  enabled = selectedPageIndex < pages.lastIndex,
                  onClick = { onMovePage(selectedPageIndex, selectedPageIndex + 1) },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(44.dp).testTag("move_page_right"),
                ) {
                  Text("Move Right")
                  Spacer(modifier = Modifier.width(4.dp))
                  Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                }
                OutlinedButton(
                  onClick = onDuplicatePage,
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(44.dp),
                ) {
                  Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Duplicate")
                }
                OutlinedButton(
                  onClick = { pendingDeleteIndex = selectedPageIndex },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(44.dp),
                ) {
                  Icon(
                    Icons.Default.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Delete", color = MaterialTheme.colorScheme.error)
                }
              }
            }
          }
        }
      }
    }
  }

  // PDF Name & Page Settings Dialog
  if (showSettingsDialog) {
    PdfExportConfigDialog(
      defaultFileName = suggestedFileName,
      settings = settings,
      pageCount = pages.size,
      onConfirm = { config ->
        showSettingsDialog = false
        onCreatePdfRequested(config)
      },
      onDismiss = { showSettingsDialog = false },
    )
  }

  // Delete page confirmation
  pendingDeleteIndex?.let { idx ->
    ConfirmDeleteDialog(
      title = "Delete Page ${idx + 1}?",
      message = "Remove this page from your current PDF draft?",
      onConfirm = {
        pendingDeleteIndex = null
        onDeletePage(idx)
      },
      onDismiss = { pendingDeleteIndex = null },
    )
  }

  // Discard draft confirmation
  if (showDiscardConfirm) {
    ConfirmDeleteDialog(
      title = "Discard Current Pages?",
      message = "You have ${pages.size} page(s) in your workspace. Discard and return home?",
      confirmLabel = "Discard",
      onConfirm = {
        showDiscardConfirm = false
        onExitToHome()
      },
      onDismiss = { showDiscardConfirm = false },
    )
  }

  // PDF Creation Progress / Rewarded Ad Fallback / Error Dialogs
  when (pdfCreationState) {
    is PdfCreationUiState.AdUnavailableFallback -> {
      AlertDialog(
        onDismissRequest = onResetCreationState,
        title = { Text("Create Your PDF") },
        text = {
          Text(
            "A short rewarded video wasn't available right now (offline or network unavailable). You can retry loading the ad or continue generating your PDF.",
            style = MaterialTheme.typography.bodyMedium,
          )
        },
        confirmButton = {
          Button(onClick = { onContinueWithoutAd(pdfCreationState.config) }) {
            Text("Continue & Create PDF")
          }
        },
        dismissButton = {
          OutlinedButton(onClick = { onRetryAdAndGenerate(pdfCreationState.config) }) {
            Text("Retry Ad")
          }
        },
      )
    }

    is PdfCreationUiState.Generating -> {
      AlertDialog(
        onDismissRequest = {},
        title = { Text("Creating PDF") },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
              "Processing page ${pdfCreationState.current.coerceAtLeast(1)} of ${pdfCreationState.total}…",
              style = MaterialTheme.typography.bodyMedium,
            )
            LinearProgressIndicator(
              progress = {
                if (pdfCreationState.total > 0) {
                  pdfCreationState.current.toFloat() / pdfCreationState.total
                } else 0f
              },
              modifier = Modifier.fillMaxWidth(),
            )
          }
        },
        confirmButton = {},
        dismissButton = {
          TextButton(onClick = onCancelGeneration) { Text("Cancel") }
        },
      )
    }

    is PdfCreationUiState.Error -> {
      AlertDialog(
        onDismissRequest = onResetCreationState,
        title = { Text("PDF Creation Failed") },
        text = { Text(pdfCreationState.message) },
        confirmButton = {
          Button(onClick = onResetCreationState) { Text("OK") }
        },
      )
    }

    else -> Unit
  }
}

private fun Modifier.wrapContentSizeSafe(): Modifier = this

@Composable
private fun InteractiveCropCanvas(
  bitmap: Bitmap,
  cropRect: CropRect,
  onCropChange: (CropRect) -> Unit,
  modifier: Modifier = Modifier,
) {
  var localCrop by remember(cropRect) { mutableStateOf(cropRect) }
  var activeCorner by remember { mutableStateOf<DragCorner?>(null) }
  val density = LocalDensity.current
  val touchSlopPx = with(density) { 40.dp.toPx() }

  BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
    val containerW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
    val containerH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
    val imgRatio = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
    val containerRatio = containerW / containerH

    val drawW: Float
    val drawH: Float
    if (imgRatio > containerRatio) {
      drawW = containerW
      drawH = containerW / imgRatio
    } else {
      drawH = containerH
      drawW = containerH * imgRatio
    }
    val offsetX = (containerW - drawW) / 2f
    val offsetY = (containerH - drawH) / 2f

    Image(
      bitmap = bitmap.asImageBitmap(),
      contentDescription = "Manual crop preview",
      modifier = Modifier.fillMaxSize(),
      contentScale = ContentScale.Fit,
    )

    Canvas(
      modifier =
        Modifier.fillMaxSize().pointerInput(drawW, drawH, offsetX, offsetY) {
          detectDragGestures(
            onDragStart = { start ->
              val l = offsetX + localCrop.left * drawW
              val r = offsetX + localCrop.right * drawW
              val t = offsetY + localCrop.top * drawH
              val b = offsetY + localCrop.bottom * drawH
              val corners =
                listOf(
                  DragCorner.TOP_LEFT to Offset(l, t),
                  DragCorner.TOP_RIGHT to Offset(r, t),
                  DragCorner.BOTTOM_LEFT to Offset(l, b),
                  DragCorner.BOTTOM_RIGHT to Offset(r, b),
                )
              val nearest = corners.minByOrNull { (_, p) -> (p - start).getDistance() }
              activeCorner =
                if (nearest != null && (nearest.second - start).getDistance() <= touchSlopPx * 1.5f) {
                  nearest.first
                } else null
            },
            onDragEnd = {
              activeCorner = null
              onCropChange(localCrop)
            },
            onDragCancel = { activeCorner = null },
            onDrag = { change, dragAmount ->
              change.consume()
              val corner = activeCorner ?: return@detectDragGestures
              val dx = dragAmount.x / drawW
              val dy = dragAmount.y / drawH
              val minSpan = 0.12f

              localCrop =
                when (corner) {
                  DragCorner.TOP_LEFT ->
                    localCrop.copy(
                      left = (localCrop.left + dx).coerceIn(0f, localCrop.right - minSpan),
                      top = (localCrop.top + dy).coerceIn(0f, localCrop.bottom - minSpan),
                    )
                  DragCorner.TOP_RIGHT ->
                    localCrop.copy(
                      right = (localCrop.right + dx).coerceIn(localCrop.left + minSpan, 1f),
                      top = (localCrop.top + dy).coerceIn(0f, localCrop.bottom - minSpan),
                    )
                  DragCorner.BOTTOM_LEFT ->
                    localCrop.copy(
                      left = (localCrop.left + dx).coerceIn(0f, localCrop.right - minSpan),
                      bottom = (localCrop.bottom + dy).coerceIn(localCrop.top + minSpan, 1f),
                    )
                  DragCorner.BOTTOM_RIGHT ->
                    localCrop.copy(
                      right = (localCrop.right + dx).coerceIn(localCrop.left + minSpan, 1f),
                      bottom = (localCrop.bottom + dy).coerceIn(localCrop.top + minSpan, 1f),
                    )
                }
            },
          )
        },
    ) {
      val rectLeft = offsetX + localCrop.left * drawW
      val rectTop = offsetY + localCrop.top * drawH
      val rectRight = offsetX + localCrop.right * drawW
      val rectBottom = offsetY + localCrop.bottom * drawH
      val rectW = rectRight - rectLeft
      val rectH = rectBottom - rectTop

      // Dim outside crop bounds
      val scrim = Color.Black.copy(alpha = 0.45f)
      drawRect(scrim, Offset(offsetX, offsetY), Size(drawW, (rectTop - offsetY).coerceAtLeast(0f)))
      drawRect(scrim, Offset(offsetX, rectBottom), Size(drawW, (offsetY + drawH - rectBottom).coerceAtLeast(0f)))
      drawRect(scrim, Offset(offsetX, rectTop), Size((rectLeft - offsetX).coerceAtLeast(0f), rectH))
      drawRect(scrim, Offset(rectRight, rectTop), Size((offsetX + drawW - rectRight).coerceAtLeast(0f), rectH))

      val pink = Color(0xFFE83E8C)
      drawRect(
        color = pink,
        topLeft = Offset(rectLeft, rectTop),
        size = Size(rectW, rectH),
        style = Stroke(width = 2.5.dp.toPx()),
      )

      // Rule of thirds subtle lines
      val gridColor = Color.White.copy(alpha = 0.45f)
      for (i in 1..2) {
        val x = rectLeft + rectW * i / 3f
        val y = rectTop + rectH * i / 3f
        drawLine(gridColor, Offset(x, rectTop), Offset(x, rectBottom), 1.dp.toPx())
        drawLine(gridColor, Offset(rectLeft, y), Offset(rectRight, y), 1.dp.toPx())
      }

      // Corner drag handles
      val handleRadius = 11.dp.toPx()
      listOf(
        Offset(rectLeft, rectTop),
        Offset(rectRight, rectTop),
        Offset(rectLeft, rectBottom),
        Offset(rectRight, rectBottom),
      ).forEach { pt ->
        drawCircle(color = Color.White, radius = handleRadius, center = pt)
        drawCircle(color = pink, radius = handleRadius - 3.dp.toPx(), center = pt)
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PdfExportConfigDialog(
  defaultFileName: String,
  settings: UserSettings,
  pageCount: Int,
  onConfirm: (PdfGenerationConfig) -> Unit,
  onDismiss: () -> Unit,
) {
  var fileName by remember(defaultFileName) { mutableStateOf(defaultFileName.removeSuffix(".pdf")) }
  var pageSize by remember { mutableStateOf(settings.defaultPageSize) }
  var orientation by remember { mutableStateOf(PdfOrientation.PORTRAIT) }
  var imageFit by remember { mutableStateOf(PdfImageFit.PRESERVE_ASPECT) }
  var quality by remember { mutableStateOf(settings.defaultQuality) }
  var includeMargins by remember { mutableStateOf(settings.includeMargins) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("PDF Export Settings ($pageCount pages)") },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        OutlinedTextField(
          value = fileName,
          onValueChange = { fileName = it },
          label = { Text("PDF File Name") },
          suffix = { Text(".pdf") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("pdf_filename_input"),
        )

        Text("Page Size", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          PdfPageSize.entries.forEach { size ->
            FilterChip(
              selected = pageSize == size,
              onClick = { pageSize = size },
              label = { Text(size.label) },
            )
          }
        }

        if (pageSize != PdfPageSize.ORIGINAL) {
          Text("Orientation", style = MaterialTheme.typography.labelLarge)
          FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PdfOrientation.entries.forEach { orient ->
              FilterChip(
                selected = orientation == orient,
                onClick = { orientation = orient },
                label = { Text(orient.label) },
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("White Page Margins", style = MaterialTheme.typography.bodyMedium)
            Switch(checked = includeMargins, onCheckedChange = { includeMargins = it })
          }
        }

        Text("Quality & Compression", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          PdfQuality.entries.forEach { q ->
            FilterChip(
              selected = quality == q,
              onClick = { quality = q },
              label = { Text(q.label) },
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        enabled = fileName.isNotBlank(),
        onClick = {
          onConfirm(
            PdfGenerationConfig(
              fileName = fileName.trim(),
              pageSize = pageSize,
              orientation = orientation,
              imageFit = imageFit,
              quality = quality,
              includeMargins = includeMargins,
            )
          )
        },
        modifier = Modifier.testTag("confirm_generate_pdf_button"),
      ) {
        Text("Generate PDF")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}

@Composable
fun PdfCreationSuccessScreen(
  document: PdfDocumentRecord,
  onOpen: () -> Unit,
  onShare: () -> Unit,
  onSaveCopy: () -> Unit,
  onRename: () -> Unit,
  onReturnHome: () -> Unit,
) {
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(20.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth(),
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier =
            Modifier.size(64.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.tertiaryContainer),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            Icons.Default.CheckCircle,
            contentDescription = "PDF created successfully",
            tint = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.size(36.dp),
          )
        }

        Text(
          text = "PDF Created!",
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = document.displayName,
          style = MaterialTheme.typography.titleSmall,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = "${document.pageCount} ${if (document.pageCount == 1) "page" else "pages"} • ${formatFileSize(document.fileSizeBytes)}",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.SemiBold,
        )

        Spacer(modifier = Modifier.height(6.dp))

        Button(
          onClick = onOpen,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("success_open_pdf"),
        ) {
          Text("Open PDF")
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedButton(
            onClick = onShare,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("success_share_pdf"),
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Share")
          }
          OutlinedButton(
            onClick = onSaveCopy,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("success_save_copy"),
          ) {
            Text("Save Copy")
          }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          TextButton(onClick = onRename, modifier = Modifier.weight(1f)) {
            Text("Rename")
          }
          TextButton(onClick = onReturnHome, modifier = Modifier.weight(1f)) {
            Text("Return Home")
          }
        }
      }
    }
  }
}
