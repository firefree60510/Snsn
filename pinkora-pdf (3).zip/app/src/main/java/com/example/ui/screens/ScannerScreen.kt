package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.ScannedPage
import com.example.engine.ImageProcessor
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import kotlinx.coroutines.launch

@Composable
fun ScannerScreen(
  existingPageCount: Int,
  onCaptureAccepted: (File, Boolean) -> Unit,
  onOpenGalleryFromScanner: () -> Unit,
  onFinishScanning: () -> Unit,
  onClose: () -> Unit,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val scope = rememberCoroutineScope()

  var hasCameraPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
        PackageManager.PERMISSION_GRANTED
    )
  }
  var permissionDeniedForever by remember { mutableStateOf(false) }

  val permissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      hasCameraPermission = granted
      if (!granted) {
        permissionDeniedForever = true
      }
    }

  LaunchedEffect(Unit) {
    if (!hasCameraPermission) {
      permissionLauncher.launch(Manifest.permission.CAMERA)
    }
  }

  BackHandler { onClose() }

  var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
  var isCapturing by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var capturedPreviewFile by remember { mutableStateOf<File?>(null) }
  var capturedPreviewPage by remember { mutableStateOf<ScannedPage?>(null) }
  var capturedPreviewBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
  var applyAutoCropOnPreview by remember { mutableStateOf(true) }

  val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
  DisposableEffect(Unit) {
    onDispose {
      cameraExecutor.shutdown()
      capturedPreviewBitmap?.recycle()
    }
  }

  // Re-render captured preview bitmap when auto-crop toggle changes
  LaunchedEffect(capturedPreviewPage, applyAutoCropOnPreview) {
    val page = capturedPreviewPage ?: return@LaunchedEffect
    val bmp =
      ImageProcessor.renderProcessedBitmap(
        page = page,
        maxDimension = 1280,
        applyCrop = applyAutoCropOnPreview,
      )
    capturedPreviewBitmap?.recycle()
    capturedPreviewBitmap = bmp
  }

  if (!hasCameraPermission) {
    CameraPermissionDeniedView(
      onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
      onOpenAppSettings = {
        val intent =
          Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
          }
        context.startActivity(intent)
      },
      onImportGallery = onOpenGalleryFromScanner,
      onClose = onClose,
      showSettingsHint = permissionDeniedForever,
    )
    return
  }

  // Captured single-page confirmation screen
  val previewFile = capturedPreviewFile
  if (previewFile != null) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Color(0xFF120D11))
          .statusBarsPadding()
          .navigationBarsPadding(),
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Bar
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          IconButton(onClick = {
            previewFile.delete()
            capturedPreviewFile = null
            capturedPreviewPage = null
          }) {
            Icon(Icons.Default.Close, contentDescription = "Retake photo", tint = Color.White)
          }
          Text(
            text = "Captured Page Preview",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
          )
          Surface(
            shape = RoundedCornerShape(12.dp),
            color =
              if (applyAutoCropOnPreview) MaterialTheme.colorScheme.primary
              else Color.White.copy(alpha = 0.14f),
            modifier =
              Modifier.clip(RoundedCornerShape(12.dp)).clickable {
                applyAutoCropOnPreview = !applyAutoCropOnPreview
              },
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Icon(
                Icons.Default.AutoFixHigh,
                contentDescription = "Toggle smart edge crop",
                tint = Color.White,
                modifier = Modifier.size(16.dp),
              )
              Text(
                text = if (applyAutoCropOnPreview) "Auto Crop" else "Full Frame",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
              )
            }
          }
        }

        // Large Fitted Preview
        Box(
          modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
          contentAlignment = Alignment.Center,
        ) {
          val bmp = capturedPreviewBitmap
          if (bmp != null) {
            Image(
              bitmap = bmp.asImageBitmap(),
              contentDescription = "Captured document preview",
              modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp)),
              contentScale = ContentScale.Fit,
            )
          } else {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
          }
        }

        // Bottom Actions
        Row(
          modifier = Modifier.fillMaxWidth().padding(16.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = {
              previewFile.delete()
              capturedPreviewFile = null
              capturedPreviewPage = null
            },
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
            modifier = Modifier.weight(1f).height(48.dp).testTag("retake_button"),
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Retake", color = Color.White)
          }

          OutlinedButton(
            onClick = {
              val file = previewFile
              capturedPreviewFile = null
              capturedPreviewPage = null
              onCaptureAccepted(file, true) // keep scanning
            },
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
            modifier = Modifier.weight(1f).height(48.dp).testTag("scan_next_button"),
          ) {
            Text("Scan Next", color = MaterialTheme.colorScheme.primary)
          }

          Button(
            onClick = {
              val file = previewFile
              capturedPreviewFile = null
              capturedPreviewPage = null
              onCaptureAccepted(file, false) // go straight to editor
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("accept_scan_button"),
          ) {
            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Use Page")
          }
        }
      }
    }
    return
  }

  // Live CameraX Preview
  val imageCapture = remember {
    ImageCapture.Builder()
      .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
      .build()
  }
  var cameraRef by remember { mutableStateOf<Camera?>(null) }

  LaunchedEffect(flashMode) {
    imageCapture.flashMode = flashMode
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Color.Black)
        .statusBarsPadding()
        .navigationBarsPadding(),
  ) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { ctx ->
        val previewView =
          PreviewView(ctx).apply {
            layoutParams =
              ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
              )
            scaleType = PreviewView.ScaleType.FILL_CENTER
          }

        val providerFuture = ProcessCameraProvider.getInstance(ctx)
        providerFuture.addListener(
          {
            runCatching {
              val provider = providerFuture.get()
              val preview =
                Preview.Builder().build().also {
                  it.setSurfaceProvider(previewView.surfaceProvider)
                }
              provider.unbindAll()
              cameraRef =
                provider.bindToLifecycle(
                  lifecycleOwner,
                  CameraSelector.DEFAULT_BACK_CAMERA,
                  preview,
                  imageCapture,
                )
            }.onFailure { err ->
              errorMessage = err.message ?: "Unable to start camera on this device."
            }
          },
          ContextCompat.getMainExecutor(ctx),
        )
        previewView
      },
    )

    // Framing guide overlay
    Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 104.dp)) {
      val w = size.width
      val h = size.height
      val corner = 34.dp.toPx()
      val stroke = 3.dp.toPx()
      val pink = Color(0xFFE83E8C)

      drawRect(
        color = Color.White.copy(alpha = 0.25f),
        topLeft = Offset.Zero,
        size = Size(w, h),
        style = Stroke(width = 1.dp.toPx()),
      )

      // 4 Pinkora corner brackets
      // Top-left
      drawLine(pink, Offset(0f, 0f), Offset(corner, 0f), stroke)
      drawLine(pink, Offset(0f, 0f), Offset(0f, corner), stroke)
      // Top-right
      drawLine(pink, Offset(w - corner, 0f), Offset(w, 0f), stroke)
      drawLine(pink, Offset(w, 0f), Offset(w, corner), stroke)
      // Bottom-left
      drawLine(pink, Offset(0f, h), Offset(corner, h), stroke)
      drawLine(pink, Offset(0f, h - corner), Offset(0f, h), stroke)
      // Bottom-right
      drawLine(pink, Offset(w - corner, h), Offset(w, h), stroke)
      drawLine(pink, Offset(w, h - corner), Offset(w, h), stroke)
    }

    // Top controls
    Row(
      modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Surface(
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.55f),
      ) {
        IconButton(onClick = onClose, modifier = Modifier.testTag("scanner_close_button")) {
          Icon(Icons.Default.Close, contentDescription = "Close scanner", tint = Color.White)
        }
      }

      Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.Black.copy(alpha = 0.55f),
      ) {
        Text(
          text = "Align document inside pink frame",
          style = MaterialTheme.typography.labelMedium,
          color = Color.White,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        )
      }

      Surface(
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.55f),
      ) {
        IconButton(
          onClick = {
            flashMode =
              when (flashMode) {
                ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
                ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO
                else -> ImageCapture.FLASH_MODE_OFF
              }
          },
          modifier = Modifier.testTag("scanner_flash_button"),
        ) {
          Icon(
            imageVector =
              when (flashMode) {
                ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                ImageCapture.FLASH_MODE_AUTO -> Icons.Default.FlashAuto
                else -> Icons.Default.FlashOff
              },
            contentDescription = "Toggle flash",
            tint = Color.White,
          )
        }
      }
    }

    errorMessage?.let { msg ->
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.align(Alignment.Center).padding(24.dp),
      ) {
        Column(
          modifier = Modifier.padding(18.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Text(msg, color = MaterialTheme.colorScheme.onErrorContainer, textAlign = TextAlign.Center)
          Spacer(modifier = Modifier.height(10.dp))
          Button(onClick = onOpenGalleryFromScanner) {
            Text("Import from Gallery Instead")
          }
        }
      }
    }

    // Bottom Capture Bar
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .align(Alignment.BottomCenter)
          .background(Color.Black.copy(alpha = 0.55f))
          .padding(horizontal = 24.dp, vertical = 18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      // Gallery Import
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier =
          Modifier.clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onOpenGalleryFromScanner)
            .padding(8.dp)
            .testTag("scanner_gallery_button"),
      ) {
        Icon(Icons.Default.Collections, contentDescription = "Import from Gallery", tint = Color.White)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Gallery", style = MaterialTheme.typography.labelSmall, color = Color.White)
      }

      // Shutter Button
      Box(
        modifier =
          Modifier.size(74.dp)
            .clip(CircleShape)
            .border(4.dp, Color.White, CircleShape)
            .padding(6.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
            .clickable(enabled = !isCapturing) {
              isCapturing = true
              val scansDir = File(context.cacheDir, "scans").apply { mkdirs() }
              val outFile = File(scansDir, "cam_${UUID.randomUUID()}.jpg")
              val outputOpts = ImageCapture.OutputFileOptions.Builder(outFile).build()
              imageCapture.takePicture(
                outputOpts,
                cameraExecutor,
                object : ImageCapture.OnImageSavedCallback {
                  override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    scope.launch {
                      val pageRes = ImageProcessor.createPageFromFile(outFile, runAutoEdgeDetect = true)
                      isCapturing = false
                      pageRes
                        .onSuccess { page ->
                          capturedPreviewPage = page
                          capturedPreviewFile = outFile
                        }
                        .onFailure { err ->
                          errorMessage = err.message ?: "Failed to process captured image."
                        }
                    }
                  }

                  override fun onError(exception: ImageCaptureException) {
                    scope.launch {
                      isCapturing = false
                      errorMessage = exception.message ?: "Capture failed. Please try again."
                    }
                  }
                },
              )
            }
            .testTag("scanner_capture_button"),
        contentAlignment = Alignment.Center,
      ) {
        if (isCapturing) {
          CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
        } else {
          Icon(Icons.Default.CameraAlt, contentDescription = "Capture document", tint = Color.White)
        }
      }

      // Done / Review button
      if (existingPageCount > 0) {
        Button(
          onClick = onFinishScanning,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          modifier = Modifier.height(48.dp).testTag("scanner_done_button"),
        ) {
          Text("Done ($existingPageCount)")
        }
      } else {
        Spacer(modifier = Modifier.width(72.dp))
      }
    }
  }
}

@Composable
private fun CameraPermissionDeniedView(
  onRequestPermission: () -> Unit,
  onOpenAppSettings: () -> Unit,
  onImportGallery: () -> Unit,
  onClose: () -> Unit,
  showSettingsHint: Boolean,
) {
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier =
            Modifier.size(64.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.surfaceVariant),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            Icons.Default.CameraAlt,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(32.dp),
          )
        }
        Text(
          text = "Camera Permission Needed",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center,
        )
        Text(
          text = "Pinkora PDF needs camera access to scan physical paper documents. All images stay strictly on your device.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Button(
          onClick = onRequestPermission,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
          Text("Allow Camera")
        }
        if (showSettingsHint) {
          OutlinedButton(
            onClick = onOpenAppSettings,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp),
          ) {
            Text("Open App Settings")
          }
        }
        OutlinedButton(
          onClick = onImportGallery,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
          Text("Import from Gallery Instead")
        }
        OutlinedButton(
          onClick = onClose,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
          Text("Go Back")
        }
      }
    }
  }
}
