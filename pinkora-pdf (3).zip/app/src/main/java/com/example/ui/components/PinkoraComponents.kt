package com.example.ui.components

import android.content.Context
import android.content.ContextWrapper
import androidx.activity.ComponentActivity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.PdfDocumentRecord
import java.io.File

tailrec fun Context.findActivity(): ComponentActivity? =
  when (this) {
    is ComponentActivity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
  }

/**
 * Original Pinkora PDF Brand Emblem (vector drawn on Canvas — clean folded document + pink scan beam).
 */
@Composable
fun PinkoraBrandMark(
  modifier: Modifier = Modifier,
  size: Dp = 36.dp,
) {
  Image(
    painter = painterResource(id = R.drawable.img_pinkora_icon),
    contentDescription = "PDF Pro logo",
    modifier = modifier.size(size).clip(RoundedCornerShape(10.dp)),
    contentScale = ContentScale.Crop,
  )
}

@Composable
fun PdfDocumentRowCard(
  document: PdfDocumentRecord,
  onOpen: () -> Unit,
  onShare: () -> Unit,
  onRename: () -> Unit,
  onDelete: () -> Unit,
  onDetails: (() -> Unit)? = null,
  onRemoveStale: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  var menuExpanded by remember { mutableStateOf(false) }

  Surface(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .clickable(onClick = onOpen)
        .testTag("pdf_item_card_${document.id}"),
    shape = RoundedCornerShape(18.dp),
    color = MaterialTheme.colorScheme.surface,
    border =
      BorderStroke(
        1.dp,
        if (document.fileExists) MaterialTheme.colorScheme.outlineVariant
        else MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
      ),
    tonalElevation = 1.dp,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // Document thumbnail
      Box(
        modifier =
          Modifier.size(width = 52.dp, height = 66.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
      ) {
        if (document.thumbnailPath != null && document.fileExists) {
          AsyncImage(
            model = File(document.thumbnailPath),
            contentDescription = "Preview of ${document.displayName}",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
          )
        } else {
          Icon(
            imageVector =
              if (document.fileExists) Icons.Filled.PictureAsPdf
              else Icons.Outlined.WarningAmber,
            contentDescription = null,
            tint =
              if (document.fileExists) MaterialTheme.colorScheme.primary
              else MaterialTheme.colorScheme.error,
            modifier = Modifier.size(28.dp),
          )
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = document.displayName,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(4.dp))
        if (document.fileExists) {
          Text(
            text = "${document.pageCount} ${if (document.pageCount == 1) "page" else "pages"} • ${formatFileSize(document.fileSizeBytes)}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = formatShortDate(document.createdAt),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        } else {
          Text(
            text = "File moved or deleted externally",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
          )
          if (onRemoveStale != null) {
            TextButton(onClick = onRemoveStale) {
              Text("Remove stale entry", color = MaterialTheme.colorScheme.error)
            }
          }
        }
      }

      Box {
        IconButton(
          onClick = { menuExpanded = true },
          modifier = Modifier.testTag("pdf_menu_${document.id}"),
        ) {
          Icon(
            imageVector = Icons.Default.MoreVert,
            contentDescription = "Options for ${document.displayName}",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        DropdownMenu(
          expanded = menuExpanded,
          onDismissRequest = { menuExpanded = false },
        ) {
          if (document.fileExists) {
            DropdownMenuItem(
              text = { Text("Open") },
              leadingIcon = { Icon(Icons.Outlined.FolderOpen, contentDescription = null) },
              onClick = {
                menuExpanded = false
                onOpen()
              },
            )
            DropdownMenuItem(
              text = { Text("Share") },
              leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
              onClick = {
                menuExpanded = false
                onShare()
              },
            )
            DropdownMenuItem(
              text = { Text("Rename") },
              leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null) },
              onClick = {
                menuExpanded = false
                onRename()
              },
            )
            if (onDetails != null) {
              DropdownMenuItem(
                text = { Text("Details") },
                leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                onClick = {
                  menuExpanded = false
                  onDetails()
                },
              )
            }
          }
          DropdownMenuItem(
            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
            leadingIcon = {
              Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            },
            onClick = {
              menuExpanded = false
              onDelete()
            },
          )
        }
      }
    }
  }
}

@Composable
fun EmptyDocumentsState(
  onCreateFirstPdf: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(24.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_empty_docs),
        contentDescription = "No saved PDFs yet illustration",
        modifier =
          Modifier.size(width = 180.dp, height = 135.dp)
            .clip(RoundedCornerShape(18.dp)),
        contentScale = ContentScale.Crop,
      )
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = "No PDFs Yet",
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Scan paper documents or pick photos from your gallery to create your first PDF.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(18.dp))
      Button(
        onClick = onCreateFirstPdf,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.height(48.dp).testTag("create_first_pdf_button"),
      ) {
        Text("Create your first PDF")
      }
    }
  }
}

@Composable
fun RenamePdfDialog(
  currentName: String,
  onConfirm: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var text by remember(currentName) { mutableStateOf(currentName.removeSuffix(".pdf").removeSuffix(".PDF")) }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Rename PDF") },
    text = {
      Column {
        Text(
          "Enter a new file name (.pdf will be added automatically).",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
          value = text,
          onValueChange = { text = it },
          singleLine = true,
          label = { Text("File Name") },
          modifier = Modifier.fillMaxWidth().testTag("rename_pdf_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(text.trim()) },
        enabled = text.isNotBlank(),
        modifier = Modifier.testTag("confirm_rename_button"),
      ) {
        Text("Rename")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}

@Composable
fun ConfirmDeleteDialog(
  title: String,
  message: String,
  confirmLabel: String = "Delete",
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
        modifier = Modifier.testTag("confirm_delete_button"),
      ) {
        Text(confirmLabel)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}

@Composable
fun DocumentDetailsDialog(
  document: PdfDocumentRecord,
  onDismiss: () -> Unit,
  onOpen: () -> Unit,
  onShare: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Document Details") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        DetailRow("Name", document.displayName)
        DetailRow("Pages", "${document.pageCount}")
        DetailRow("File Size", formatFileSize(document.fileSizeBytes))
        DetailRow("Created", formatDate(document.createdAt))
        DetailRow("Location", "App Private Documents (Local)")
      }
    },
    confirmButton = {
      Button(onClick = {
        onDismiss()
        onOpen()
      }) {
        Text("Open PDF")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = {
        onDismiss()
        onShare()
      }) {
        Text("Share")
      }
    },
  )
}

@Composable
private fun DetailRow(label: String, value: String) {
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(modifier = Modifier.width(12.dp))
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.onSurface,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(1f, fill = false),
    )
  }
}
