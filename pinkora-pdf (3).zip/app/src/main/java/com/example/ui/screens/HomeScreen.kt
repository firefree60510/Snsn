package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ads.PinkoraNativeAdCard
import com.example.data.model.PdfDocumentRecord
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DocumentDetailsDialog
import com.example.ui.components.EmptyDocumentsState
import com.example.ui.components.PdfDocumentRowCard
import com.example.ui.components.PinkoraBrandMark
import com.example.ui.components.RenamePdfDialog

@Composable
fun HomeScreen(
  recentDocuments: List<PdfDocumentRecord>,
  onOpenGalleryPicker: () -> Unit,
  onOpenScanner: () -> Unit,
  onOpenCreateSourceDialog: () -> Unit,
  onOpenMyFiles: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenDocument: (PdfDocumentRecord) -> Unit,
  onShareDocument: (PdfDocumentRecord) -> Unit,
  onRenameDocument: (PdfDocumentRecord, String) -> Unit,
  onDeleteDocument: (PdfDocumentRecord) -> Unit,
  onRemoveStaleRecord: (Long) -> Unit,
  modifier: Modifier = Modifier,
) {
  var renameTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }
  var deleteTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }
  var detailsTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }

  BoxWithConstraints(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    val isWide = maxWidth >= 600.dp

    LazyColumn(
      modifier = Modifier.widthIn(max = 840.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Header
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            PinkoraBrandMark(size = 42.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "PDF Pro",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
              )
              Text(
                text = "Scan. Create. Save. Share.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium,
              )
            }
          }

          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            IconButton(
              onClick = onOpenSettings,
              modifier = Modifier.testTag("home_settings_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.Settings,
                contentDescription = "Settings",
                tint = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }
      }

      // Main Hero Card
      item {
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(24.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .background(
                  Brush.horizontalGradient(
                    colors =
                      listOf(
                        MaterialTheme.colorScheme.surfaceVariant,
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                      )
                  )
                )
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(20.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Your Documents, Perfectly Organized",
                  style = MaterialTheme.typography.headlineSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "Scan documents and create PDFs in seconds.",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                  onClick = onOpenScanner,
                  shape = RoundedCornerShape(14.dp),
                  colors =
                    ButtonDefaults.buttonColors(
                      containerColor = MaterialTheme.colorScheme.primary,
                      contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                  modifier = Modifier.height(48.dp).testTag("hero_scan_button"),
                ) {
                  Icon(
                    imageVector = Icons.Default.DocumentScanner,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Scan Document")
                }
              }

              Spacer(modifier = Modifier.width(12.dp))

              Image(
                painter = painterResource(id = R.drawable.img_hero_scan),
                contentDescription = "Document scanning artwork",
                modifier =
                  Modifier.size(width = if (isWide) 160.dp else 96.dp, height = 112.dp)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop,
              )
            }
          }
        }
      }

      // 4 Main Action Cards
      item {
        val actions =
          listOf(
            HomeActionItem(
              title = "Gallery to PDF",
              description = "Turn photos into a PDF.",
              icon = Icons.Default.Collections,
              tag = "action_gallery_to_pdf",
              onClick = onOpenGalleryPicker,
            ),
            HomeActionItem(
              title = "Scan Document",
              description = "Scan paper documents.",
              icon = Icons.Default.DocumentScanner,
              tag = "action_scan_document",
              onClick = onOpenScanner,
            ),
            HomeActionItem(
              title = "Create PDF",
              description = "Combine images and documents.",
              icon = Icons.AutoMirrored.Filled.NoteAdd,
              tag = "action_create_pdf",
              onClick = onOpenCreateSourceDialog,
            ),
            HomeActionItem(
              title = "My PDFs",
              description = "View and manage saved PDFs.",
              icon = Icons.Default.FolderCopy,
              tag = "action_my_pdfs",
              onClick = onOpenMyFiles,
            ),
          )

        if (isWide) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            actions.forEach { item ->
              HomeActionCard(item = item, modifier = Modifier.weight(1f))
            }
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              HomeActionCard(item = actions[0], modifier = Modifier.weight(1f))
              HomeActionCard(item = actions[1], modifier = Modifier.weight(1f))
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              HomeActionCard(item = actions[2], modifier = Modifier.weight(1f))
              HomeActionCard(item = actions[3], modifier = Modifier.weight(1f))
            }
          }
        }
      }

      // Natural Native Ad Slot between Quick Actions & Recent Docs
      item {
        PinkoraNativeAdCard(modifier = Modifier.padding(vertical = 2.dp))
      }

      // Recent Documents Section
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "Recent Documents",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
          )
          if (recentDocuments.isNotEmpty()) {
            TextButton(onClick = onOpenMyFiles) {
              Text("See All")
            }
          }
        }
      }

      if (recentDocuments.isEmpty()) {
        item {
          AnimatedVisibility(visible = true, enter = fadeIn(), exit = fadeOut()) {
            EmptyDocumentsState(onCreateFirstPdf = onOpenCreateSourceDialog)
          }
        }
      } else {
        items(recentDocuments.take(5), key = { it.id }) { doc ->
          PdfDocumentRowCard(
            document = doc,
            onOpen = { onOpenDocument(doc) },
            onShare = { onShareDocument(doc) },
            onRename = { renameTarget = doc },
            onDelete = { deleteTarget = doc },
            onDetails = { detailsTarget = doc },
            onRemoveStale = { onRemoveStaleRecord(doc.id) },
          )
        }
      }

      item { Spacer(modifier = Modifier.height(8.dp)) }
    }
  }

  renameTarget?.let { target ->
    RenamePdfDialog(
      currentName = target.displayName,
      onConfirm = { newName ->
        renameTarget = null
        onRenameDocument(target, newName)
      },
      onDismiss = { renameTarget = null },
    )
  }

  deleteTarget?.let { target ->
    ConfirmDeleteDialog(
      title = "Delete PDF?",
      message = "Permanently delete \"${target.displayName}\" from your device?",
      onConfirm = {
        deleteTarget = null
        onDeleteDocument(target)
      },
      onDismiss = { deleteTarget = null },
    )
  }

  detailsTarget?.let { target ->
    DocumentDetailsDialog(
      document = target,
      onDismiss = { detailsTarget = null },
      onOpen = { onOpenDocument(target) },
      onShare = { onShareDocument(target) },
    )
  }
}

private data class HomeActionItem(
  val title: String,
  val description: String,
  val icon: ImageVector,
  val tag: String,
  val onClick: () -> Unit,
)

@Composable
private fun HomeActionCard(
  item: HomeActionItem,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier =
      modifier
        .clip(RoundedCornerShape(20.dp))
        .clickable(onClick = item.onClick)
        .testTag(item.tag),
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Box(
        modifier =
          Modifier.size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = item.icon,
          contentDescription = item.title,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(24.dp),
        )
      }
      Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
          text = item.title,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = item.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}
