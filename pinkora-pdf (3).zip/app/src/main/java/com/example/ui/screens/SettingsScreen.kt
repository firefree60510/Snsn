package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Feedback
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.PdfDocumentRecord
import com.example.data.model.PdfPageSize
import com.example.data.model.PdfQuality
import com.example.data.model.ThemePreference
import com.example.data.model.UserSettings
import com.example.ui.components.PinkoraBrandMark
import com.example.ui.components.formatFileSize

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
  settings: UserSettings,
  documents: List<PdfDocumentRecord>,
  onUpdateTheme: (ThemePreference) -> Unit,
  onUpdateDefaultPageSize: (PdfPageSize) -> Unit,
  onUpdateDefaultQuality: (PdfQuality) -> Unit,
  onUpdateNamingPrefix: (String) -> Unit,
  onUpdateIncludeMargins: (Boolean) -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var prefixDraft by remember(settings.defaultNamingPrefix) { mutableStateOf(settings.defaultNamingPrefix) }
  val totalStorageUsed = remember(documents) { documents.filter { it.fileExists }.sumOf { it.fileSizeBytes } }

  BoxWithConstraints(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 760.dp).fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      item {
        Text(
          text = "Settings",
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.Bold,
        )
      }

      // Theme Preference
      item {
        SettingsCard(title = "Appearance") {
          Text(
            text = "Theme Mode",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
          )
          Spacer(modifier = Modifier.height(8.dp))
          FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemePreference.entries.forEach { mode ->
              FilterChip(
                selected = settings.themePreference == mode,
                onClick = { onUpdateTheme(mode) },
                label = { Text(mode.label) },
                modifier = Modifier.testTag("theme_chip_${mode.name}"),
              )
            }
          }
        }
      }

      // Default PDF Export Preferences
      item {
        SettingsCard(title = "PDF Creation Defaults") {
          Text(
            text = "Default Page Size",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
          )
          Spacer(modifier = Modifier.height(6.dp))
          FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PdfPageSize.entries.forEach { size ->
              FilterChip(
                selected = settings.defaultPageSize == size,
                onClick = { onUpdateDefaultPageSize(size) },
                label = { Text(size.label) },
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = "Default Image Quality",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
          )
          Spacer(modifier = Modifier.height(6.dp))
          FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PdfQuality.entries.forEach { quality ->
              FilterChip(
                selected = settings.defaultQuality == quality,
                onClick = { onUpdateDefaultQuality(quality) },
                label = { Text(quality.label) },
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("White Page Margins", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
              Text(
                "Add clean padding around document pages by default.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = settings.includeMargins,
              onCheckedChange = onUpdateIncludeMargins,
            )
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = "Default Output Naming Prefix",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedTextField(
              value = prefixDraft,
              onValueChange = { prefixDraft = it },
              singleLine = true,
              modifier = Modifier.weight(1f),
              placeholder = { Text("Pinkora_Document") },
            )
            Button(
              onClick = {
                onUpdateNamingPrefix(prefixDraft)
                onShowMessage("Saved default filename prefix.")
              },
              modifier = Modifier.height(52.dp),
            ) {
              Text("Save")
            }
          }
        }
      }

      // Storage & Privacy Info
      item {
        SettingsCard(title = "Storage & Privacy") {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Outlined.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column {
              Text("Local Document Storage", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
              Text(
                "${documents.count { it.fileExists }} saved PDFs using ${formatFileSize(totalStorageUsed)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

          Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column {
              Text("100% On-Device Processing", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
              Text(
                "All image scanning, cropping, filtering, and PDF generation happens locally on your phone. Your documents are never uploaded to external servers.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }

      // About & Feedback
      item {
        SettingsCard(title = "About PDF Pro") {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PinkoraBrandMark(size = 44.dp)
            Column {
              Text("PDF Pro", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              Text(
                "Version 1.0 • Scan. Create. Save. Share.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedButton(
            onClick = {
              val intent =
                Intent(Intent.ACTION_SENDTO).apply {
                  data = Uri.parse("mailto:")
                  putExtra(Intent.EXTRA_SUBJECT, "PDF Pro Feedback (v1.0)")
                }
              runCatching { context.startActivity(intent) }.onFailure {
                onShowMessage("No email app found on this device.")
              }
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp),
          ) {
            Icon(Icons.Outlined.Feedback, contentDescription = null)
            Spacer(modifier = Modifier.padding(horizontal = 4.dp))
            Text("Send Feedback")
          }
        }
      }
    }
  }
}

@Composable
private fun SettingsCard(
  title: String,
  content: @Composable () -> Unit,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
      )
      Spacer(modifier = Modifier.height(12.dp))
      content()
    }
  }
}
