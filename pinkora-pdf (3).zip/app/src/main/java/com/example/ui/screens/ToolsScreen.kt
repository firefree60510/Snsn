package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallSplit
import androidx.compose.material.icons.automirrored.filled.MergeType
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FilterNone
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.PdfDocumentRecord
import com.example.data.model.PdfQuality
import com.example.ui.ToolExecutionState
import com.example.ui.components.RenamePdfDialog
import com.example.ui.components.formatFileSize

private enum class ActiveTool {
  SPLIT,
  EXTRACT,
  ROTATE,
  COMPRESS,
  INFO,
  PICK_FOR_RENAME,
  PICK_FOR_SHARE,
}

private data class PdfToolCardData(
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  val tag: String,
  val onClick: () -> Unit,
)

@Composable
fun ToolsScreen(
  savedDocuments: List<PdfDocumentRecord>,
  toolState: ToolExecutionState,
  onStartImagesToPdf: () -> Unit,
  onMergePdfs: (List<Uri>, String) -> Unit,
  onSplitOrExtractPdf: (Uri, List<Int>, String, String) -> Unit,
  onRotatePdf: (Uri, Int, String) -> Unit,
  onCompressPdf: (Uri, PdfQuality, String) -> Unit,
  onInspectPdf: (Uri) -> Unit,
  onRenameDocument: (PdfDocumentRecord, String) -> Unit,
  onShareDocument: (PdfDocumentRecord) -> Unit,
  onOpenGeneratedDocument: (PdfDocumentRecord) -> Unit,
  onResetToolState: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var activeTool by remember { mutableStateOf<ActiveTool?>(null) }
  var pendingUri by remember { mutableStateOf<Uri?>(null) }
  var renameTarget by remember { mutableStateOf<PdfDocumentRecord?>(null) }

  val mergePicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
      if (uris.size >= 2) {
        onMergePdfs(uris, "Pinkora_Merged_${System.currentTimeMillis() % 10000}")
      }
    }

  val singlePdfPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        when (activeTool) {
          ActiveTool.INFO -> onInspectPdf(uri)
          ActiveTool.SPLIT, ActiveTool.EXTRACT, ActiveTool.ROTATE, ActiveTool.COMPRESS -> {
            pendingUri = uri
          }
          else -> Unit
        }
      } else {
        activeTool = null
      }
    }

  val tools =
    listOf(
      PdfToolCardData(
        title = "Images to PDF",
        subtitle = "Convert gallery photos with crop & filters",
        icon = Icons.Default.Collections,
        tag = "tool_images_to_pdf",
        onClick = onStartImagesToPdf,
      ),
      PdfToolCardData(
        title = "Merge PDFs",
        subtitle = "Combine 2 or more PDF files in order",
        icon = Icons.AutoMirrored.Filled.MergeType,
        tag = "tool_merge_pdfs",
        onClick = { mergePicker.launch(arrayOf("application/pdf")) },
      ),
      PdfToolCardData(
        title = "Split by Range",
        subtitle = "Save a page range (e.g. 1-3) as a PDF",
        icon = Icons.AutoMirrored.Filled.CallSplit,
        tag = "tool_split_pdf",
        onClick = {
          activeTool = ActiveTool.SPLIT
          singlePdfPicker.launch(arrayOf("application/pdf"))
        },
      ),
      PdfToolCardData(
        title = "Extract Pages",
        subtitle = "Pick specific pages like 1, 3, 5",
        icon = Icons.Default.FilterNone,
        tag = "tool_extract_pages",
        onClick = {
          activeTool = ActiveTool.EXTRACT
          singlePdfPicker.launch(arrayOf("application/pdf"))
        },
      ),
      PdfToolCardData(
        title = "Rotate PDF",
        subtitle = "Rotate all pages 90°, 180°, or 270°",
        icon = Icons.AutoMirrored.Filled.RotateRight,
        tag = "tool_rotate_pdf",
        onClick = {
          activeTool = ActiveTool.ROTATE
          singlePdfPicker.launch(arrayOf("application/pdf"))
        },
      ),
      PdfToolCardData(
        title = "Compress PDF",
        subtitle = "Optimize size with quality presets",
        icon = Icons.Default.Compress,
        tag = "tool_compress_pdf",
        onClick = {
          activeTool = ActiveTool.COMPRESS
          singlePdfPicker.launch(arrayOf("application/pdf"))
        },
      ),
      PdfToolCardData(
        title = "Rename PDF",
        subtitle = "Rename a saved document cleanly",
        icon = Icons.Default.DriveFileRenameOutline,
        tag = "tool_rename_pdf",
        onClick = { activeTool = ActiveTool.PICK_FOR_RENAME },
      ),
      PdfToolCardData(
        title = "Share PDF",
        subtitle = "Send a saved PDF via Android share",
        icon = Icons.Default.Share,
        tag = "tool_share_pdf",
        onClick = { activeTool = ActiveTool.PICK_FOR_SHARE },
      ),
      PdfToolCardData(
        title = "PDF Info",
        subtitle = "Inspect page count, dimensions & metadata",
        icon = Icons.Default.Info,
        tag = "tool_pdf_info",
        onClick = {
          activeTool = ActiveTool.INFO
          singlePdfPicker.launch(arrayOf("application/pdf"))
        },
      ),
    )

  BoxWithConstraints(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    val cols = if (maxWidth >= 600.dp) 3 else 2

    LazyVerticalGrid(
      columns = GridCells.Fixed(cols),
      modifier = Modifier.widthIn(max = 840.dp).fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item(span = { GridItemSpan(cols) }) {
        Column {
          Text(
            text = "PDF Utilities",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Real offline PDF processing powered on your device.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Spacer(modifier = Modifier.height(6.dp))
        }
      }

      items(tools, key = { it.title }) { tool ->
        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .clip(RoundedCornerShape(20.dp))
              .clickable(onClick = tool.onClick)
              .testTag(tool.tag),
          shape = RoundedCornerShape(20.dp),
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          tonalElevation = 1.dp,
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Box(
              modifier =
                Modifier.size(44.dp)
                  .clip(RoundedCornerShape(14.dp))
                  .background(MaterialTheme.colorScheme.surfaceVariant),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = tool.icon,
                contentDescription = tool.title,
                tint = MaterialTheme.colorScheme.primary,
              )
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Text(
                text = tool.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = tool.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }
    }
  }

  // Tool Parameter Dialogs
  val uri = pendingUri
  if (uri != null) {
    when (activeTool) {
      ActiveTool.SPLIT -> {
        SplitRangeDialog(
          onConfirm = { start, end, name ->
            val list = (start..end).toList()
            pendingUri = null
            activeTool = null
            onSplitOrExtractPdf(uri, list, name, "Splitting PDF")
          },
          onDismiss = {
            pendingUri = null
            activeTool = null
          },
        )
      }
      ActiveTool.EXTRACT -> {
        ExtractPagesDialog(
          onConfirm = { pages, name ->
            pendingUri = null
            activeTool = null
            onSplitOrExtractPdf(uri, pages, name, "Extracting pages")
          },
          onDismiss = {
            pendingUri = null
            activeTool = null
          },
        )
      }
      ActiveTool.ROTATE -> {
        RotatePdfDialog(
          onConfirm = { deg, name ->
            pendingUri = null
            activeTool = null
            onRotatePdf(uri, deg, name)
          },
          onDismiss = {
            pendingUri = null
            activeTool = null
          },
        )
      }
      ActiveTool.COMPRESS -> {
        CompressPdfDialog(
          onConfirm = { quality, name ->
            pendingUri = null
            activeTool = null
            onCompressPdf(uri, quality, name)
          },
          onDismiss = {
            pendingUri = null
            activeTool = null
          },
        )
      }
      else -> Unit
    }
  }

  if (activeTool == ActiveTool.PICK_FOR_RENAME || activeTool == ActiveTool.PICK_FOR_SHARE) {
    SavedPdfPickerDialog(
      title = if (activeTool == ActiveTool.PICK_FOR_RENAME) "Choose PDF to Rename" else "Choose PDF to Share",
      documents = savedDocuments.filter { it.fileExists },
      onSelect = { doc ->
        val mode = activeTool
        activeTool = null
        if (mode == ActiveTool.PICK_FOR_RENAME) {
          renameTarget = doc
        } else {
          onShareDocument(doc)
        }
      },
      onDismiss = { activeTool = null },
    )
  }

  renameTarget?.let { target ->
    RenamePdfDialog(
      currentName = target.displayName,
      onConfirm = { newName ->
        renameTarget = null
        onRenameDocument(target, newName)
      },
      onDismiss = { renameTarget = null },
    )
  }

  // Tool execution result / loading dialogs
  when (toolState) {
    is ToolExecutionState.Working -> {
      AlertDialog(
        onDismissRequest = {},
        title = { Text("Processing PDF") },
        text = {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(toolState.label, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(14.dp))
            val prog = toolState.progress
            if (prog != null && prog.second > 0) {
              LinearProgressIndicator(
                progress = { prog.first.toFloat() / prog.second },
                modifier = Modifier.fillMaxWidth(),
              )
            } else {
              CircularProgressIndicator()
            }
          }
        },
        confirmButton = {},
      )
    }
    is ToolExecutionState.ResultDocument -> {
      AlertDialog(
        onDismissRequest = onResetToolState,
        title = { Text("Done!") },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(toolState.summary, style = MaterialTheme.typography.bodyMedium)
            Text(
              "Size: ${formatFileSize(toolState.document.fileSizeBytes)}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        },
        confirmButton = {
          Button(onClick = {
            val doc = toolState.document
            onResetToolState()
            onOpenGeneratedDocument(doc)
          }) {
            Text("Open PDF")
          }
        },
        dismissButton = {
          OutlinedButton(onClick = {
            val doc = toolState.document
            onResetToolState()
            onShareDocument(doc)
          }) {
            Text("Share")
          }
        },
      )
    }
    is ToolExecutionState.InfoResult -> {
      val info = toolState.metadata
      AlertDialog(
        onDismissRequest = onResetToolState,
        title = { Text("PDF Information") },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("File: ${info.fileName}", fontWeight = FontWeight.SemiBold)
            Text("Pages: ${info.pageCount}")
            Text("Size: ${formatFileSize(info.fileSizeBytes)}")
            Text("First Page: ${info.firstPageSizeText}")
            Text("PDF Version: ${info.pdfVersion}")
            info.title?.let { Text("Title: $it") }
            info.author?.let { Text("Author: $it") }
            info.creator?.let { Text("Creator: $it") }
          }
        },
        confirmButton = {
          Button(onClick = onResetToolState) { Text("Close") }
        },
      )
    }
    is ToolExecutionState.Error -> {
      AlertDialog(
        onDismissRequest = onResetToolState,
        title = { Text("Operation Failed") },
        text = { Text(toolState.message) },
        confirmButton = {
          Button(onClick = onResetToolState) { Text("OK") }
        },
      )
    }
    ToolExecutionState.Idle -> Unit
  }
}

@Composable
private fun SplitRangeDialog(
  onConfirm: (Int, Int, String) -> Unit,
  onDismiss: () -> Unit,
) {
  var startText by remember { mutableStateOf("1") }
  var endText by remember { mutableStateOf("2") }
  var outputName by remember { mutableStateOf("Pinkora_Split_${System.currentTimeMillis() % 1000}") }

  val start = startText.toIntOrNull()
  val end = endText.toIntOrNull()
  val valid = start != null && end != null && start >= 1 && end >= start && outputName.isNotBlank()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Split PDF by Page Range") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = startText,
            onValueChange = { startText = it.filter(Char::isDigit) },
            label = { Text("Start Page") },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          OutlinedTextField(
            value = endText,
            onValueChange = { endText = it.filter(Char::isDigit) },
            label = { Text("End Page") },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
        }
        OutlinedTextField(
          value = outputName,
          onValueChange = { outputName = it },
          label = { Text("Output Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(enabled = valid, onClick = { onConfirm(start!!, end!!, outputName) }) {
        Text("Split")
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
  )
}

@Composable
private fun ExtractPagesDialog(
  onConfirm: (List<Int>, String) -> Unit,
  onDismiss: () -> Unit,
) {
  var pagesText by remember { mutableStateOf("1") }
  var outputName by remember { mutableStateOf("Pinkora_Extracted_${System.currentTimeMillis() % 1000}") }
  val parsedPages =
    pagesText.split(",", " ").mapNotNull { it.trim().toIntOrNull() }.filter { it > 0 }.distinct()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Extract Selected Pages") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          "Enter page numbers separated by commas (e.g., 1, 3, 4).",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
          value = pagesText,
          onValueChange = { pagesText = it },
          label = { Text("Pages (1-based)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = outputName,
          onValueChange = { outputName = it },
          label = { Text("Output Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        enabled = parsedPages.isNotEmpty() && outputName.isNotBlank(),
        onClick = { onConfirm(parsedPages, outputName) },
      ) {
        Text("Extract")
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
  )
}

@Composable
private fun RotatePdfDialog(
  onConfirm: (Int, String) -> Unit,
  onDismiss: () -> Unit,
) {
  var selectedDegrees by remember { mutableIntStateOf(90) }
  var outputName by remember { mutableStateOf("Pinkora_Rotated_${System.currentTimeMillis() % 1000}") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Rotate PDF Pages") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf(90, 180, 270).forEach { deg ->
            FilterChip(
              selected = selectedDegrees == deg,
              onClick = { selectedDegrees = deg },
              label = { Text("${deg}°") },
            )
          }
        }
        OutlinedTextField(
          value = outputName,
          onValueChange = { outputName = it },
          label = { Text("Output Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(enabled = outputName.isNotBlank(), onClick = { onConfirm(selectedDegrees, outputName) }) {
        Text("Rotate")
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
  )
}

@Composable
private fun CompressPdfDialog(
  onConfirm: (PdfQuality, String) -> Unit,
  onDismiss: () -> Unit,
) {
  var selectedQuality by remember { mutableStateOf(PdfQuality.MEDIUM) }
  var outputName by remember { mutableStateOf("Pinkora_Compressed_${System.currentTimeMillis() % 1000}") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Compress PDF") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          "Smaller file presets reduce embedded image resolution to save storage.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          PdfQuality.entries.forEach { quality ->
            FilterChip(
              selected = selectedQuality == quality,
              onClick = { selectedQuality = quality },
              label = { Text(quality.label) },
            )
          }
        }
        OutlinedTextField(
          value = outputName,
          onValueChange = { outputName = it },
          label = { Text("Output Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(enabled = outputName.isNotBlank(), onClick = { onConfirm(selectedQuality, outputName) }) {
        Text("Compress")
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
  )
}

@Composable
private fun SavedPdfPickerDialog(
  title: String,
  documents: List<PdfDocumentRecord>,
  onSelect: (PdfDocumentRecord) -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      if (documents.isEmpty()) {
        Text("No saved PDFs found yet. Create or import a PDF first.")
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxWidth().height(260.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items(documents.size) { index ->
            val doc = documents[index]
            Surface(
              modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onSelect(doc) },
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(doc.displayName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                  "${doc.pageCount} pages • ${formatFileSize(doc.fileSizeBytes)}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Close") }
    },
  )
}
