package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pinkora PDF Signature Brand Palette
val PrimaryPink = Color(0xFFE83E8C)
val DeepPink = Color(0xFFC92B72)
val SoftPinkBackground = Color(0xFFFFF4F8)
val LightPinkSurface = Color(0xFFFFE3EE)
val SoftPinkBorder = Color(0xFFF7C9DC)
val PureWhite = Color(0xFFFFFFFF)
val WarmWhite = Color(0xFFFFFBFD)

val PrimaryText = Color(0xFF24212A)
val SecondaryText = Color(0xFF77717B)
val SuccessGreen = Color(0xFF1FA971)
val SuccessContainer = Color(0xFFE6F8F0)
val ErrorRed = Color(0xFFD9364F)
val ErrorContainer = Color(0xFFFDE8EC)

// Dark Mode Counterparts
val DarkBackground = Color(0xFF161115)
val DarkSurface = Color(0xFF20181E)
val DarkSurfaceVariant = Color(0xFF2E222B)
val DarkPrimaryPink = Color(0xFFFF7EB6)
val DarkDeepPink = Color(0xFFE83E8C)
val DarkTextPrimary = Color(0xFFF9F1F5)
val DarkTextSecondary = Color(0xFFC7B8C1)
val DarkOutline = Color(0xFF473742)
