package com.example.ui

import android.app.Activity
import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PinkoraApplication
import com.example.ads.AdMobConfig
import com.example.ads.PinkoraAdManager
import com.example.data.model.CropRect
import com.example.data.model.PdfDocumentRecord
import com.example.data.model.PdfGenerationConfig
import com.example.data.model.PdfInfoMetadata
import com.example.data.model.PdfPageSize
import com.example.data.model.PdfQuality
import com.example.data.model.PdfSortOption
import com.example.data.model.ResizePreset
import com.example.data.model.ScanFilter
import com.example.data.model.ScannedPage
import com.example.data.model.ThemePreference
import com.example.data.model.UserSettings
import com.example.engine.ImageProcessor
import com.example.engine.PdfEngine
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface PdfCreationUiState {
  data object Idle : PdfCreationUiState

  data class Generating(val current: Int, val total: Int) : PdfCreationUiState

  data class AdUnavailableFallback(val config: PdfGenerationConfig) : PdfCreationUiState

  data class Success(val document: PdfDocumentRecord) : PdfCreationUiState

  data class Error(val message: String) : PdfCreationUiState
}

sealed interface ToolExecutionState {
  data object Idle : ToolExecutionState

  data class Working(val label: String, val progress: Pair<Int, Int>? = null) : ToolExecutionState

  data class ResultDocument(val document: PdfDocumentRecord, val summary: String) : ToolExecutionState

  data class InfoResult(val metadata: PdfInfoMetadata) : ToolExecutionState

  data class Error(val message: String) : ToolExecutionState
}

class PinkoraViewModel(application: Application) : AndroidViewModel(application) {

  private val app = application as PinkoraApplication
  val documentRepository = app.documentRepository
  private val settingsRepository = app.settingsRepository
  val adManager = PinkoraAdManager(application.applicationContext)

  init {
    viewModelScope.launch {
      AdMobConfig.isSdkInitialized.first { it }
      adManager.preloadAll()
    }
  }

  val settings: StateFlow<UserSettings> =
    settingsRepository.settingsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = UserSettings(),
    )

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _sortOption = MutableStateFlow(PdfSortOption.NEWEST)
  val sortOption: StateFlow<PdfSortOption> = _sortOption.asStateFlow()

  private val _isGridView = MutableStateFlow(false)
  val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

  val allDocuments: StateFlow<List<PdfDocumentRecord>> =
    documentRepository.documentsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  val filteredDocuments: StateFlow<List<PdfDocumentRecord>> =
    combine(allDocuments, _searchQuery, _sortOption) { docs, query, sort ->
        val filtered =
          if (query.isBlank()) docs
          else docs.filter { it.displayName.contains(query.trim(), ignoreCase = true) }

        when (sort) {
          PdfSortOption.NEWEST -> filtered.sortedByDescending { it.createdAt }
          PdfSortOption.OLDEST -> filtered.sortedBy { it.createdAt }
          PdfSortOption.NAME -> filtered.sortedBy { it.displayName.lowercase() }
          PdfSortOption.SIZE -> filtered.sortedByDescending { it.fileSizeBytes }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  private val _sessionPages = MutableStateFlow<List<ScannedPage>>(emptyList())
  val sessionPages: StateFlow<List<ScannedPage>> = _sessionPages.asStateFlow()

  private val _selectedPageIndex = MutableStateFlow(0)
  val selectedPageIndex: StateFlow<Int> = _selectedPageIndex.asStateFlow()

  private val _isImportingImages = MutableStateFlow(false)
  val isImportingImages: StateFlow<Boolean> = _isImportingImages.asStateFlow()

  private val _pdfCreationState = MutableStateFlow<PdfCreationUiState>(PdfCreationUiState.Idle)
  val pdfCreationState: StateFlow<PdfCreationUiState> = _pdfCreationState.asStateFlow()

  private val _toolState = MutableStateFlow<ToolExecutionState>(ToolExecutionState.Idle)
  val toolState: StateFlow<ToolExecutionState> = _toolState.asStateFlow()

  private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
  val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

  private var generationJob: Job? = null

  fun postMessage(msg: String) {
    _snackbarMessages.tryEmit(msg)
  }

  // Filter & Search for My Files
  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setSortOption(option: PdfSortOption) {
    _sortOption.value = option
  }

  fun toggleGridView() {
    _isGridView.value = !_isGridView.value
  }

  // Settings updates
  fun updateTheme(theme: ThemePreference) = viewModelScope.launch { settingsRepository.updateTheme(theme) }

  fun updateDefaultPageSize(size: PdfPageSize) =
    viewModelScope.launch { settingsRepository.updateDefaultPageSize(size) }

  fun updateDefaultQuality(quality: PdfQuality) =
    viewModelScope.launch { settingsRepository.updateDefaultQuality(quality) }

  fun updateDefaultNamingPrefix(prefix: String) =
    viewModelScope.launch { settingsRepository.updateDefaultNamingPrefix(prefix) }

  fun updateIncludeMargins(include: Boolean) =
    viewModelScope.launch { settingsRepository.updateIncludeMargins(include) }

  // Image Import & Camera Capture Session
  fun importGalleryUris(
    uris: List<Uri>,
    append: Boolean = false,
    onCompleted: (Boolean) -> Unit = {},
  ) {
    if (uris.isEmpty()) {
      onCompleted(false)
      return
    }
    viewModelScope.launch {
      _isImportingImages.value = true
      val imported = mutableListOf<ScannedPage>()
      var failedCount = 0

      uris.forEach { uri ->
        val res = ImageProcessor.importUriToScanPage(app, uri, runAutoEdgeDetect = true)
        res.onSuccess { imported.add(it) }.onFailure { failedCount++ }
      }

      if (imported.isNotEmpty()) {
        val current = if (append) _sessionPages.value else emptyList()
        val combined = current + imported
        _sessionPages.value = combined
        _selectedPageIndex.value = if (append) current.size else 0
        if (failedCount > 0) {
          postMessage("Imported ${imported.size} images ($failedCount unsupported skipped).")
        }
        onCompleted(true)
      } else {
        postMessage("Could not import the selected image(s). Try standard PNG or JPEG images.")
        onCompleted(false)
      }
      _isImportingImages.value = false
    }
  }

  fun addCapturedFile(file: File, append: Boolean = true, onReady: (Boolean) -> Unit = {}) {
    viewModelScope.launch {
      _isImportingImages.value = true
      val res = ImageProcessor.createPageFromFile(file, runAutoEdgeDetect = true)
      res
        .onSuccess { page ->
          val base = if (append) _sessionPages.value else emptyList()
          _sessionPages.value = base + page
          _selectedPageIndex.value = base.size
          onReady(true)
        }
        .onFailure {
          postMessage(it.message ?: "Failed to process captured document.")
          onReady(false)
        }
      _isImportingImages.value = false
    }
  }

  fun selectPage(index: Int) {
    if (index in _sessionPages.value.indices) {
      _selectedPageIndex.value = index
    }
  }

  fun rotateSelectedPage(deltaDegrees: Int) {
    updateSelectedPage { page ->
      val nextRot = ((page.rotationDegrees + deltaDegrees) % 360 + 360) % 360
      page.copy(rotationDegrees = nextRot)
    }
  }

  fun updateSelectedCrop(cropRect: CropRect) {
    updateSelectedPage { it.copy(cropRect = cropRect) }
  }

  fun applyAutoEdgeCropToSelected() {
    val page = currentSelectedPage() ?: return
    val detected = page.autoDetectedCropRect
    if (detected != null && !detected.isFull) {
      updateSelectedPage { it.copy(cropRect = detected) }
      postMessage("Auto document boundary applied.")
    } else {
      viewModelScope.launch {
        val bmp = ImageProcessor.renderProcessedBitmap(page.copy(cropRect = CropRect()), 1200, applyCrop = false)
        if (bmp != null) {
          val found = ImageProcessor.detectDocumentEdges(bmp)
          bmp.recycle()
          updateSelectedPage { it.copy(cropRect = found, autoDetectedCropRect = found) }
          postMessage(
            if (found.isFull) "Document edges already span full frame."
            else "Smart document edges detected."
          )
        }
      }
    }
  }

  fun resetSelectedCrop() {
    updateSelectedPage { it.copy(cropRect = CropRect()) }
  }

  fun updateSelectedFilter(filter: ScanFilter) {
    updateSelectedPage { it.copy(filter = filter) }
  }

  fun applyFilterToAllPages(filter: ScanFilter) {
    _sessionPages.value = _sessionPages.value.map { it.copy(filter = filter) }
    postMessage("Applied ${filter.label} to all pages.")
  }

  fun updateSelectedResize(preset: ResizePreset, scale: Float) {
    updateSelectedPage { it.copy(resizePreset = preset, resizeScale = scale.coerceIn(0.35f, 1f)) }
  }

  fun movePage(fromIndex: Int, toIndex: Int) {
    val list = _sessionPages.value.toMutableList()
    if (fromIndex !in list.indices || toIndex !in list.indices || fromIndex == toIndex) return
    val item = list.removeAt(fromIndex)
    list.add(toIndex, item)
    _sessionPages.value = list
    _selectedPageIndex.value = toIndex
  }

  fun duplicateSelectedPage() {
    val list = _sessionPages.value.toMutableList()
    val idx = _selectedPageIndex.value
    if (idx !in list.indices) return
    val copy = list[idx].copy(id = java.util.UUID.randomUUID().toString())
    list.add(idx + 1, copy)
    _sessionPages.value = list
    _selectedPageIndex.value = idx + 1
  }

  fun deletePage(index: Int) {
    val list = _sessionPages.value.toMutableList()
    if (index !in list.indices) return
    list.removeAt(index)
    _sessionPages.value = list
    _selectedPageIndex.value =
      when {
        list.isEmpty() -> 0
        index >= list.size -> list.lastIndex
        else -> index
      }
  }

  fun clearSession() {
    _sessionPages.value = emptyList()
    _selectedPageIndex.value = 0
  }

  private fun currentSelectedPage(): ScannedPage? {
    val list = _sessionPages.value
    val idx = _selectedPageIndex.value
    return list.getOrNull(idx)
  }

  private fun updateSelectedPage(transform: (ScannedPage) -> ScannedPage) {
    val list = _sessionPages.value.toMutableList()
    val idx = _selectedPageIndex.value
    if (idx !in list.indices) return
    list[idx] = transform(list[idx])
    _sessionPages.value = list
  }

  fun suggestPdfName(): String {
    return documentRepository.suggestNextPdfName(settings.value.defaultNamingPrefix)
  }

  /**
   * Rewarded-Ad gated final PDF generation with clean fallback if ad isn't loaded.
   */
  fun requestPdfGenerationWithRewardedAd(activity: Activity?, config: PdfGenerationConfig) {
    if (_sessionPages.value.isEmpty()) {
      _pdfCreationState.value = PdfCreationUiState.Error("Add at least one image before creating a PDF.")
      return
    }
    adManager.showRewardedForPdfExport(
      activity = activity,
      onRewardEarned = { executePdfGeneration(config) },
      onAdUnavailable = { _pdfCreationState.value = PdfCreationUiState.AdUnavailableFallback(config) },
      onAdDismissedWithoutReward = {
        postMessage("Watch the short ad completely to generate your PDF, or tap Create PDF again.")
      },
    )
  }

  fun executePdfGeneration(config: PdfGenerationConfig) {
    val pages = _sessionPages.value.toList()
    if (pages.isEmpty()) return

    generationJob?.cancel()
    generationJob =
      viewModelScope.launch {
        _pdfCreationState.value = PdfCreationUiState.Generating(0, pages.size)
        val (pdfFile, thumbFile) = documentRepository.resolveUniqueTargetFiles(config.fileName)
        val result =
          PdfEngine.generatePdfFromPages(
            context = app,
            pages = pages,
            config = config,
            outputPdfFile = pdfFile,
            outputThumbFile = thumbFile,
            onProgress = { current, total ->
              _pdfCreationState.value = PdfCreationUiState.Generating(current, total)
            },
          )

        result
          .onSuccess { generated ->
            val saved = documentRepository.registerGeneratedPdf(generated)
            _pdfCreationState.value = PdfCreationUiState.Success(saved)
          }
          .onFailure { err ->
            if (err is CancellationException) {
              _pdfCreationState.value = PdfCreationUiState.Idle
              postMessage("PDF generation cancelled.")
            } else {
              _pdfCreationState.value =
                PdfCreationUiState.Error(err.message ?: "Unable to create PDF.")
            }
          }
      }
  }

  fun cancelPdfGeneration() {
    generationJob?.cancel()
    _pdfCreationState.value = PdfCreationUiState.Idle
  }

  fun resetPdfCreationState() {
    _pdfCreationState.value = PdfCreationUiState.Idle
  }

  // Document management
  fun renameDocument(record: PdfDocumentRecord, newName: String, onUpdated: (PdfDocumentRecord) -> Unit = {}) {
    viewModelScope.launch {
      documentRepository
        .renameDocument(record, newName)
        .onSuccess {
          postMessage("Renamed to ${it.displayName}")
          onUpdated(it)
        }
        .onFailure { postMessage(it.message ?: "Rename failed.") }
    }
  }

  fun deleteDocument(record: PdfDocumentRecord) {
    viewModelScope.launch {
      documentRepository
        .deleteDocument(record)
        .onSuccess { postMessage("Deleted ${record.displayName}") }
        .onFailure { postMessage(it.message ?: "Delete failed.") }
    }
  }

  fun removeStaleDocument(id: Long) {
    viewModelScope.launch {
      documentRepository.removeStaleRecord(id)
      postMessage("Removed missing file entry.")
    }
  }

  fun exportDocumentToUri(record: PdfDocumentRecord, destinationUri: Uri) {
    viewModelScope.launch {
      documentRepository
        .exportPdfToUri(record, destinationUri)
        .onSuccess { postMessage("Saved copy to chosen location.") }
        .onFailure { postMessage(it.message ?: "Failed to save copy.") }
    }
  }

  fun importExternalPdf(uri: Uri) {
    viewModelScope.launch {
      documentRepository
        .importExternalPdf(uri)
        .onSuccess { postMessage("Imported ${it.displayName}") }
        .onFailure { postMessage(it.message ?: "Could not import PDF.") }
    }
  }

  // PDF Utilities
  fun resetToolState() {
    _toolState.value = ToolExecutionState.Idle
  }

  fun mergePdfs(uris: List<Uri>, outputName: String) {
    viewModelScope.launch {
      _toolState.value = ToolExecutionState.Working("Merging ${uris.size} PDFs…")
      val (outPdf, outThumb) = documentRepository.resolveUniqueTargetFiles(outputName)
      PdfEngine.mergePdfs(app, uris, outPdf, outThumb)
        .onSuccess { res ->
          val saved = documentRepository.registerGeneratedPdf(res)
          _toolState.value =
            ToolExecutionState.ResultDocument(
              saved,
              "Merged ${uris.size} files into ${saved.pageCount} pages.",
            )
        }
        .onFailure {
          _toolState.value = ToolExecutionState.Error(it.message ?: "Merge failed.")
        }
    }
  }

  fun splitOrExtractPdf(uri: Uri, pages: List<Int>, outputName: String, actionLabel: String) {
    viewModelScope.launch {
      _toolState.value = ToolExecutionState.Working("$actionLabel…")
      val (outPdf, outThumb) = documentRepository.resolveUniqueTargetFiles(outputName)
      PdfEngine.splitOrExtractPdf(app, uri, pages, outPdf, outThumb)
        .onSuccess { res ->
          val saved = documentRepository.registerGeneratedPdf(res)
          _toolState.value =
            ToolExecutionState.ResultDocument(
              saved,
              "Created ${saved.displayName} with ${saved.pageCount} page(s).",
            )
        }
        .onFailure {
          _toolState.value = ToolExecutionState.Error(it.message ?: "Operation failed.")
        }
    }
  }

  fun rotatePdf(uri: Uri, degrees: Int, outputName: String) {
    viewModelScope.launch {
      _toolState.value = ToolExecutionState.Working("Rotating PDF pages by $degrees°…")
      val (outPdf, outThumb) = documentRepository.resolveUniqueTargetFiles(outputName)
      PdfEngine.rotatePdfPages(app, uri, degrees, outPdf, outThumb)
        .onSuccess { res ->
          val saved = documentRepository.registerGeneratedPdf(res)
          _toolState.value =
            ToolExecutionState.ResultDocument(
              saved,
              "Rotated all ${saved.pageCount} pages by $degrees°.",
            )
        }
        .onFailure {
          _toolState.value = ToolExecutionState.Error(it.message ?: "Rotate failed.")
        }
    }
  }

  fun compressPdf(uri: Uri, quality: PdfQuality, outputName: String) {
    viewModelScope.launch {
      _toolState.value = ToolExecutionState.Working("Optimizing PDF pages…")
      val (outPdf, outThumb) = documentRepository.resolveUniqueTargetFiles(outputName)
      PdfEngine.compressPdf(app, uri, quality, outPdf, outThumb) { cur, tot ->
          _toolState.value = ToolExecutionState.Working("Compressing page $cur of $tot…", cur to tot)
        }
        .onSuccess { res ->
          val saved = documentRepository.registerGeneratedPdf(res)
          _toolState.value =
            ToolExecutionState.ResultDocument(
              saved,
              "Compressed PDF (${saved.pageCount} pages) saved.",
            )
        }
        .onFailure {
          _toolState.value = ToolExecutionState.Error(it.message ?: "Compression failed.")
        }
    }
  }

  fun inspectPdfInfo(uri: Uri) {
    viewModelScope.launch {
      _toolState.value = ToolExecutionState.Working("Inspecting PDF metadata…")
      val name = documentRepository.resolveDisplayName(uri) ?: "Document.pdf"
      PdfEngine.inspectPdfInfo(app, uri, name)
        .onSuccess { _toolState.value = ToolExecutionState.InfoResult(it) }
        .onFailure { _toolState.value = ToolExecutionState.Error(it.message ?: "Unable to inspect PDF.") }
    }
  }
}
