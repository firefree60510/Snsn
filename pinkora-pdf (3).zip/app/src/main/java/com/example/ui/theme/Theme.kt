package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import com.example.data.model.ThemePreference

private val PinkoraLightColorScheme =
  lightColorScheme(
    primary = PrimaryPink,
    onPrimary = PureWhite,
    primaryContainer = LightPinkSurface,
    onPrimaryContainer = DeepPink,
    secondary = DeepPink,
    onSecondary = PureWhite,
    secondaryContainer = LightPinkSurface,
    onSecondaryContainer = PrimaryText,
    tertiary = SuccessGreen,
    onTertiary = PureWhite,
    tertiaryContainer = SuccessContainer,
    onTertiaryContainer = SuccessGreen,
    background = SoftPinkBackground,
    onBackground = PrimaryText,
    surface = PureWhite,
    onSurface = PrimaryText,
    surfaceVariant = LightPinkSurface,
    onSurfaceVariant = SecondaryText,
    surfaceContainerLowest = PureWhite,
    surfaceContainerLow = WarmWhite,
    surfaceContainer = PureWhite,
    surfaceContainerHigh = SoftPinkBackground,
    surfaceContainerHighest = LightPinkSurface,
    outline = SoftPinkBorder,
    outlineVariant = LightPinkSurface,
    error = ErrorRed,
    onError = PureWhite,
    errorContainer = ErrorContainer,
    onErrorContainer = ErrorRed,
  )

private val PinkoraDarkColorScheme =
  darkColorScheme(
    primary = DarkPrimaryPink,
    onPrimary = DarkBackground,
    primaryContainer = DarkDeepPink,
    onPrimaryContainer = PureWhite,
    secondary = DarkPrimaryPink,
    onSecondary = DarkBackground,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = DarkTextPrimary,
    tertiary = SuccessGreen,
    onTertiary = PureWhite,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    surfaceContainerLowest = DarkBackground,
    surfaceContainerLow = DarkSurface,
    surfaceContainer = DarkSurface,
    surfaceContainerHigh = DarkSurfaceVariant,
    surfaceContainerHighest = DarkOutline,
    outline = DarkOutline,
    outlineVariant = DarkSurfaceVariant,
    error = ErrorRed,
    onError = PureWhite,
  )

val PinkoraShapes =
  Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(24.dp),
  )

@Composable
fun PinkoraPdfTheme(
  themePreference: ThemePreference = ThemePreference.LIGHT,
  content: @Composable () -> Unit,
) {
  val darkTheme =
    when (themePreference) {
      ThemePreference.LIGHT -> false
      ThemePreference.DARK -> true
      ThemePreference.SYSTEM -> isSystemInDarkTheme()
    }

  val colorScheme = if (darkTheme) PinkoraDarkColorScheme else PinkoraLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    shapes = PinkoraShapes,
    content = content,
  )
}
