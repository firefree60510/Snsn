package com.example.ui.components

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatFileSize(bytes: Long): String {
  if (bytes < 1024L) return "$bytes B"
  val kb = bytes / 1024.0
  if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
  val mb = kb / 1024.0
  return String.format(Locale.US, "%.2f MB", mb)
}

fun formatDate(epochMillis: Long): String {
  return SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date(epochMillis))
}

fun formatShortDate(epochMillis: Long): String {
  return SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(epochMillis))
}
