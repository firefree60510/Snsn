package com.example

import android.app.Application
import com.example.ads.AdMobConfig
import com.example.data.local.PinkoraDatabase
import com.example.data.local.SettingsRepository
import com.example.data.repository.DocumentRepository
import com.google.android.gms.ads.MobileAds
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PinkoraApplication : Application() {

  private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  val database: PinkoraDatabase by lazy { PinkoraDatabase.getInstance(this) }
  val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
  val documentRepository: DocumentRepository by lazy {
    DocumentRepository(this, database.documentDao())
  }

  override fun onCreate() {
    super.onCreate()
    runCatching { PDFBoxResourceLoader.init(applicationContext) }
    appScope.launch {
      runCatching {
        MobileAds.initialize(this@PinkoraApplication) {
          AdMobConfig.markSdkInitialized()
        }
      }
    }
  }
}
